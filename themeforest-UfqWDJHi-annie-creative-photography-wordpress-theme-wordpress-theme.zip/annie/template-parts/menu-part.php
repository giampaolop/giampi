<?php $annie_options = get_option('annie'); ?>
<!-- Sidebar -->
<aside class="annie-aside">
    <!-- Logo -->
    <div class="annie-logo">
	<?php if ($annie_options['textlogo']=="st2") { ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url(annie_AfterSetupTheme::return_thme_option('logopic','url'));?>" alt="<?php  bloginfo('name'); ?>"></a>
	<?php };?>
	<?php if ($annie_options['sitetitle_opt']!="st2") { ?>
        <h2>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php  bloginfo('name'); ?><span><?php bloginfo( 'description' ); ?></span></a>
		</h2> 
	<?php } ;?>
	</div>
	<!-- Menu -->
    <nav class="annie-main-menu">
        <ul>
            <?php
			$defaults = array(
				'theme_location'  => 'top-menu',
				'menu'            => 'nav',
				'container'       => '',
				'container_class' => '',
				'menu_class'      => '',
				'menu_id'         => '',
				'echo'            => true,
				'fallback_cb'     => 'show_top_menu',
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => '%3$s',
				'depth'           => 0,
				'walker'          => '',									
			);
			if(has_nav_menu('top-menu')) {
				wp_nav_menu( $defaults );
			}   
			?>
        </ul>
    </nav>
	<!-- Sidebar Footer -->
    <div class="annie-footer">
		<?php if($annie_options['social-icon-site'] == 'yes') :?>
        <ul>
		<?php if(!empty($annie_options['facebook'])):?> 
			<li><a href="<?php echo esc_url($annie_options['facebook']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-facebook"></i></a></li>
		<?php endif;?>

		<?php if(!empty($annie_options['twitter'])):?> 
			<li><a href="<?php echo esc_url($annie_options['twitter']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-x-twitter"></i></a></li>
		<?php endif;?>

		<?php if(!empty($annie_options['tiktok'])):?> 
			<li><a href="<?php echo esc_url($annie_options['tiktok']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-tiktok"></i></a></li>
		<?php endif;?>		

		<?php if(!empty($annie_options['linkedin'])):?> 
			<li><a href="<?php echo esc_url($annie_options['linkedin']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-linkedin"></i></a></li>
		<?php endif;?>	

		<?php if(!empty($annie_options['instagram'])):?> 
			<li><a href="<?php echo esc_url($annie_options['instagram']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-instagram"></i></a></li>
		<?php endif;?>	

		<?php if(!empty($annie_options['pinterest'])):?> 
			<li><a href="<?php echo esc_url($annie_options['pinterest']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-pinterest-alt"></i></a></li>
		<?php endif;?>	

		<?php if(!empty($annie_options['soundcloud'])):?> 
			<li><a href="<?php echo esc_url($annie_options['soundcloud']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-soundcloud"></i></a></li>
		<?php endif;?>			

		<?php if(!empty($annie_options['skype'])):?> 
			<li><a href="<?php echo esc_url($annie_options['skype']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-skype"></i></a></li>
		<?php endif;?>	
				
		<?php if(!empty($annie_options['dribbble'])):?> 
			<li><a href="<?php echo esc_url($annie_options['dribbble']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-dribbble"></i></a></li>
		<?php endif;?>				

		<?php if(!empty($annie_options['youtube'])):?> 
			<li><a href="<?php echo esc_url($annie_options['youtube']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-youtube"></i></a></li>
		<?php endif;?>	

		<?php if(!empty($annie_options['vimeo'])):?> 
			<li><a href="<?php echo esc_url($annie_options['vimeo']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-vimeo "></i></a></li>
		<?php endif;?>
				
		<?php if(!empty($annie_options['dropbox'])):?> 
			<li><a href="<?php echo esc_url($annie_options['dropbox']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-dropbox"></i></a></li>
		<?php endif;?>	

		<?php if(!empty($annie_options['github'])):?> 
			<li><a href="<?php echo esc_url($annie_options['github']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-github"></i></a></li>
		<?php endif;?>	
		<?php if(!empty($annie_options['tumblr'])):?> 
			<li><a href="<?php echo esc_url($annie_options['tumblr']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-tumblr-alt"></i></a></li>
		<?php endif;?>
		<?php if(!empty($annie_options['email'])):?> 
			<li><a href="mailto:<?php echo esc_attr($annie_options['email']); ?>" target="_blank" rel="noopener noreferrer"><i class="ti-email"></i></a></li>
		<?php endif;?>
		</ul>
	<?php endif;?>
				
		<?php if ($annie_options['menu_copy_opt']!="st2") {?>
			<div class="footer_copyright_info">	<?php echo do_shortcode(($annie_options['copyright']));?></div>	
		<?php };?>
    </div>
</aside>