<?php
if( !function_exists ('annie_enqueue_scripts') ) :
	function annie_enqueue_scripts() {
	global $opt_theme_style;
	$annie_options = get_option('annie');	
	$annie_protocol = is_ssl() ? 'https' : 'http';			
	wp_enqueue_script('modernizr', (ANNIE_THEME_URL . '/includes/js/modernizr-2.6.2.min.js'), array('jquery'), '1.0',true);
	wp_enqueue_script('easing', (ANNIE_THEME_URL . '/includes/js/jquery.easing.1.3.js'), array('jquery'), '1.0',true);
	wp_enqueue_script('bootstrap', (ANNIE_THEME_URL . '/includes/js/bootstrap.min.js'), array('jquery'), '1.0',true);
	wp_enqueue_script('waypoints', (ANNIE_THEME_URL . '/includes/js/jquery.waypoints.min.js'), array('jquery'), '1.0',true);
	wp_enqueue_script('flexslider', (ANNIE_THEME_URL . '/includes/js/jquery.flexslider-min.js'), array('jquery'), '1.0',true);
	wp_enqueue_script('sticky-kit', (ANNIE_THEME_URL . '/includes/js/sticky-kit.min.js'), array('jquery'), '1.0',true);
	wp_enqueue_script('fancybox', (ANNIE_THEME_URL . '/includes/js/jquery.fancybox.min.js'), array('jquery'), '1.0',true);  
	wp_register_script('annie-map', (ANNIE_THEME_URL . '/includes/js/map-min.js'), array('jquery'), '1.0',true);  
	wp_register_script('annie-map-script', (ANNIE_THEME_URL . '/includes/js/map-script.js'), array('jquery'), '1.0',true);	
	wp_enqueue_script('annie-main', (ANNIE_THEME_URL . '/includes/js/main.js'), array('jquery'), '1.0',true);	
	wp_enqueue_script('annie-scrollto-script', (ANNIE_THEME_URL . '/includes/js/scrollto-script.js'), array('jquery'), '1.0',true);	
	wp_register_script('imagesloaded', (ANNIE_THEME_URL . '/includes/js/imagesloaded.pkgd.min.js'), array('jquery'), '1.0',true);	
	wp_register_script('isotope', (ANNIE_THEME_URL . '/includes/js/jquery.isotope.v3.0.2.js'), array('jquery'), '1.0',true);	
	wp_register_script('packery-mode', (ANNIE_THEME_URL . '/includes/js/packery-mode.pkgd.min.js'), array('jquery'), '1.0',true);	
	if ( !is_user_logged_in()) {
		if (annie_AfterSetupTheme::return_thme_option('content_protector')=='st2'){
			wp_enqueue_script('candore-content-protector', (ANNIE_THEME_URL . '/includes/js/content-protector.js'), array('jquery'), '1.0',true);
		}
	}	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
	}
}
	add_action('wp_enqueue_scripts', 'annie_enqueue_scripts');
endif;