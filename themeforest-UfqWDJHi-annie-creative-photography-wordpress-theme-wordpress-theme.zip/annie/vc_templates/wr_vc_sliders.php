<?php
$args = array(
    	'class'=>'',		
);
$html = "";
extract(shortcode_atts($args, $atts));
$html .= '<div id="home" class="'.$class.'">'; 
    $html .= '<div class="annie-hero-vc annie-hero js-fullheight">';
        $html .= '<div class="flexslider js-fullheight">';
            $html .= '<ul class="slides">';
		        $html .= do_shortcode($content);
	        $html .='</ul>';
	    $html .='</div>';
	$html .='</div>';
$html .= '</div>';
echo $html;