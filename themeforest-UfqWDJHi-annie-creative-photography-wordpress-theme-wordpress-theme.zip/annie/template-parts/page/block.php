<?php $annie_options = get_option('annie'); ?>	
<?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>				

<div class="row">
    <div class="col-md-12 <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
	<?php the_content();
					wp_link_pages( array(
					'before'      => '<div class="page-links">',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '%',
					'separator'   => '',
					) );
					?>

 
	</div>
</div>
