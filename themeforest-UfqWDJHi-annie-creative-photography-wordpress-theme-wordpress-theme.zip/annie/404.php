<?php $annie_options = get_option('annie'); ?>
<?php get_header();?>
<?php if($annie_options['index-header-animate'] == 'yes') { 

$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
<div class="annie-about">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 text-center"> 
				<span class="heading-meta">
					<?php if(!empty($annie_options['error-page-sbtitle'])): ?>
					<?php echo esc_html(($annie_options['error-page-sbtitle']));?>
					<?php else :?>
					<?php esc_html_e('Error','annie');?>
					<?php endif;?>
				</span>
                <h2 class="<?php echo esc_attr($annie_title_class);?>" <?php echo esc_attr($annie_title_animate);?>>
				<?php if(!empty($annie_options['error-page-title'])): ?>
				<?php echo esc_html(($annie_options['error-page-title']));?>
				<?php else:?>
				<?php esc_html_e('404','annie');?>
				<?php endif;?>
				</h2>
			</div>	
		</div>
	<?php get_template_part('template-parts/animate/animate-div-start'); ?>
	<div class="col-md-8 offset-md-2 text-center">
	<div class="error-wrap error-search-wrap fl-wrap">
				
				<div class="clearfix"></div>
				<form action="<?php echo esc_url( home_url( '/'  ) ); ?>">
					<input name="s" id="se2" type="text" class="search" placeholder="<?php if(!empty($annie_options['translet_opt_7'])):?><?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('translet_opt_7',''));?><?php else: ?><?php esc_attr_e('Search..','annie');?><?php endif;?>" value="<?php if(!empty($annie_options['translet_opt_7'])):?><?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('translet_opt_7',''));?><?php else: ?><?php esc_attr_e('Search..','annie');?><?php endif;?>">
					<button class="search-submit color-bg" id="err_submit_btn"><i class="ti-search"></i> </button>
				</form>
			</div>
	</div>
	
	<?php get_template_part('template-parts/animate/animate-div-end'); ?> 
	</div>	
</div>	
<?php get_footer(); ?>	