<?php $annie_options = get_option('annie'); ?>
<?php get_header();?>
<?php if($annie_options['index-header-animate'] == 'yes') { 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
 <?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>	
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<?php $annie_blog = "col-md-12";?>
<?php $annie_blog_main = "col-md-8";?>
<?php else : ?>
<?php $annie_blog = "col-md-6";?>
<?php $annie_blog_main = "col-md-12";?>
<?php endif;?>
<!-- Blog -->
            <div class="annie-blog">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12 text-center"> 
							<span class="heading-meta">
							<?php if(!empty($annie_options['src-page-title'])): ?>
							<?php echo esc_html(($annie_options['src-page-title']));?>
							<?php else :?>
							<?php esc_html_e('Search','annie');?>
							<?php endif;?>
							</span>
                            <h2 class="<?php echo esc_attr($annie_title_class);?>" <?php echo esc_attr($annie_title_animate);?>>
							<?php if(!empty($annie_options['translet_opt_s_t'])):?><?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('translet_opt_s_t',''));?><?php else: ?><?php esc_html_e('Results for ','annie');?><?php endif;?><?php printf( esc_html__( '%s', 'annie' ), '"' . get_search_query() . '"' ); ?>
							</h2> 
						</div>
                    </div>
					
<div class="row">
<div class="<?php echo esc_attr($annie_blog_main);?>">
<div class="row">
<?php global $post, $post_id;?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="<?php echo esc_attr($annie_blog);?> <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="blog-entry">
				<?php if (has_post_thumbnail( $post->ID ) ):
				$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
                <a href="<?php the_permalink();?>" class="blog-img"><img src="<?php echo esc_url($annie_image[0]);?>" class="img-fluid" alt="<?php the_title_attribute();?>"></a>
				<?php endif;?>
                    <div class="desc"> <span><?php the_time( get_option( 'date_format' ) ); ?> <?php if( has_category() ) {?>| <?php the_category(', '); ?><?php }?></span>
                    <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                    <?php if( wp_link_pages('echo=0') ): ?>										
					<?php the_content();
					wp_link_pages( array(
					'before'      => '<div class="page-links">',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '%',
					'separator'   => '',
					) );
					?>
					<?php else : ?>
                    <?php the_excerpt(); ?>
					<?php endif;?>
                    </div>
            </div>
        </div>
    </div>
<?php endwhile;?>
<?php else : ?> 
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<?php $annie_blog_search = "col-md-12 text-center";?>
<?php else : ?>
<?php $annie_blog_search = "col-md-6 offset-md-3 text-center";?>
<?php endif;?>
<div class="<?php echo esc_attr($annie_blog_search);?> <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
	<div class="blog-entry">
		<div class="desc">
			<div class="error-wrap error-search-wrap fl-wrap">
				<h3><a href="#0"><?php if(!empty($annie_options['translet_opt_23'])):?><?php echo esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_23',''));?><?php else: ?><?php esc_html_e('No Post Found','annie');?><?php endif;?></a></h3>
				<p><?php if(!empty($annie_options['translet_opt_24'])):?><?php echo esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_24',''));?><?php else: ?><?php esc_html_e('Please Search Again.','annie');?><?php endif;?></p>
				<div class="clearfix"></div>
				<form action="<?php echo esc_url( home_url( '/'  ) ); ?>">
					<input name="s" id="se2" type="text" class="search" placeholder="<?php if(!empty($annie_options['translet_opt_7'])):?><?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('translet_opt_7',''));?><?php else: ?><?php esc_attr_e('Search..','annie');?><?php endif;?>" value="<?php if(!empty($annie_options['translet_opt_7'])):?><?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('translet_opt_7',''));?><?php else: ?><?php esc_attr_e('Search..','annie');?><?php endif;?>">
					<button class="search-submit color-bg" id="err_submit_btn"><i class="ti-search"></i> </button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php endif;?>
</div>
</div>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<div class="col-md-4">
<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
<?php endif;?>
</div>
<?php if (function_exists("annie_pagination")) {
annie_pagination($wp_query->max_num_pages);
} ;?>
                </div>
            </div>
<?php get_footer(); ?>		