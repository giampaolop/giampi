<?php $annie_options = get_option('annie'); ?>
<?php if($annie_options['index-header-animate'] == 'yes') { 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
<!-- Blog -->
            <div class="annie-blog">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12 text-center"> 
						<?php if(!empty($annie_options['blog-page-subtitle'])): ?>
							<span class="heading-meta"><?php echo esc_html(($annie_options['blog-page-subtitle']));?></span>
						<?php endif;?>	
                            <h2 class="<?php echo esc_attr($annie_title_class);?>" <?php echo esc_attr($annie_title_animate);?>>
							<?php if(!empty($annie_options['blog-page-title'])): ?>
							<?php echo esc_html(($annie_options['blog-page-title']));?>
							<?php else:?>
							<?php esc_html_e('News &amp; Blog','annie');?>
							<?php endif;?>	
							</h2> 
						</div>
                    </div>	
<?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>		
<?php if(have_posts()) : while ( have_posts() ) : the_post();?> 
<div class="row">
<div class="col-md-8">
<div class="row">

    <div class="col-md-12 <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="blog-entry">
				<?php if (has_post_thumbnail( $post->ID ) ):
				$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
                <a href="<?php the_permalink();?>" class="blog-img"><img src="<?php echo esc_url($annie_image[0]);?>" class="img-fluid en-blog-img" alt="<?php the_title_attribute();?>"></a>
				<?php endif;?>
                    <div class="desc"> <span><?php the_time( get_option( 'date_format' ) ); ?> | <?php the_category(', '); ?></span>
                    <h3><a href="#0"><?php the_title();?></a></h3>
					<?php the_content();
					wp_link_pages( array(
					'before'      => '<div class="page-links post-details-url">',
					'after'       => '</div>',
					'link_before' => '',
					'link_after'  => '',
					'pagelink'    => '%',
					'separator'   => '',
					) );
					?>
					
                    </div>
            </div>
        </div>
	<?php if ( comments_open() || get_comments_number() ) { ?>				
	<?php comments_template();?>
	<?php }?>
    </div>
	

</div>

</div>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<div class="col-md-4">
<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
<?php endif;?>
</div>
<?php endwhile;  endif; wp_reset_postdata(); ?>
</div>
</div>