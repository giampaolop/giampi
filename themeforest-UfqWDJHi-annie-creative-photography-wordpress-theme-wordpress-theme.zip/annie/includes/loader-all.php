<?php
function annie_import_files() {
	return array(
		
		array(
			'import_file_name'             => 'Dark Default Demo',
			'categories'                   => array( 'Elementor Dark' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/1.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo1/',
		),
		
		array(
			'import_file_name'             => 'Dark Parallax Image Demo',
			'categories'                   => array( 'Elementor Dark' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/1.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo1/home-image/',
		),
		
		array(
			'import_file_name'             => 'Dark Video Demo',
			'categories'                   => array( 'Elementor Dark' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/5.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo1/home-video/',
		),
		
		array(
			'import_file_name'             => 'Dark Image Sidebar Demo',
			'categories'                   => array( 'Elementor Dark' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark-sidebar/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/dark-sidebar/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/7.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo3/',
		),
		
		
		array(
			'import_file_name'             => 'Light Default Demo',
			'categories'                   => array( 'Elementor Light' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/2.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo1/',
		),
		
		array(
			'import_file_name'             => 'Light Parallax Image Demo',
			'categories'                   => array( 'Elementor Light' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/2.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo2/home-image/',
		),
		
		array(
			'import_file_name'             => 'Light Video Demo',
			'categories'                   => array( 'Elementor Light' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/6.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo2/home-video/',
		),
		
		array(
			'import_file_name'             => 'Light Image Sidebar Demo',
			'categories'                   => array( 'Elementor Light' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light-sidebar/demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/light-sidebar/redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/7.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/elementor/demo4/',
		),
		
		array(
			'import_file_name'             => 'WPBakery Dark Demo',
			'categories'                   => array( 'WPBakery Dark' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/wpbakery/dark-demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/wpbakery/dark-redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/1.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/dark/',
		),
		
		array(
			'import_file_name'             => 'WPBakery Light Demo',
			'categories'                   => array( 'WPBakery Light' ),
			'local_import_file'            => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/wpbakery/light-demo-content.xml',
			'local_import_widget_file'     => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/widgets.wie',
			//'local_import_customizer_file' => trailingslashit( ANNIE_THEME_PATH ) . 'ocdi/customizer.dat',
			'local_import_redux'           => array(
				array(
					'file_path'   => trailingslashit( ANNIE_THEME_PATH ) . 'includes/annie-demo/wpbakery/light-redux.json',
					'option_name' => 'annie',
				),
			),
			'import_preview_image_url'     => 'https://webredox.net/demo/wp/annie/img/2.png',
			'import_notice'                => __( 'Be patient, it can take a couple of minutes.', 'annie' ),
			'preview_url'                  => 'https://webredox.net/demo/wp/annie/light/',
		),
		
	);
}
add_filter( 'pt-ocdi/import_files', 'annie_import_files' );

function annie_after_import_setup( $selected_import ) {
	if ( 'Dark Default Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Dark Parallax Image Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home Image' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Dark Video Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home Video' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Dark Image Sidebar Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Light Default Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Light Parallax Image Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home Image' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Light Video Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home Video' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'Light Image Sidebar Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'WPBakery Dark Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	else if ( 'WPBakery Light Demo' === $selected_import['import_file_name'] ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'top-menu' => $main_menu->term_id,
			)
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );
	}
	

}
add_action( 'pt-ocdi/after_import', 'annie_after_import_setup' );

function ocdi_plugin_page_setup( $default_settings ) {
	$default_settings['parent_slug'] = 'themes.php';
	$default_settings['page_title']  = esc_html__( 'Annie Demo Importer' , 'annie' );
	$default_settings['menu_title']  = esc_html__( 'Annie Demo Importer' , 'annie' );
	$default_settings['capability']  = 'import';
	$default_settings['menu_slug']   = 'annie-one-click-demo-import';

	return $default_settings;
}
add_filter( 'pt-ocdi/plugin_page_setup', 'ocdi_plugin_page_setup' );
function ocdi_change_time_of_single_ajax_call() {
    return 180;
}
add_filter( 'ocdi/time_for_one_ajax_call', 'ocdi_change_time_of_single_ajax_call' );

add_filter( 'ocdi/regenerate_thumbnails_in_content_import', '__return_false' );