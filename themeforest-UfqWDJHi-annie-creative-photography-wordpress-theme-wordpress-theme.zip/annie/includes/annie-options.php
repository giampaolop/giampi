<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "annie";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'annie/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
		'class'                => 'admin-color-pimax',
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Annie Options', 'annie' ),
        'page_title'           => esc_html__( 'Annie Options', 'annie' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => 'AIzaSyCN8bSGZHdbSOXu0HbhXf8j0SnswTmbCNw',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => true,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => 90,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the annie. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'annie'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'annie'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    
    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( esc_html__( '', 'annie' ), $v );
    } else {
        $args['intro_text'] = esc_html__( '', 'annie' );
    }

    // Add content after the form.
    $args['footer_text'] = esc_html__( '', 'annie' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Support', 'annie' ),
            'content' => esc_html__( 'Send us a mail by using our item support form.', 'annie' )
        ),
        
    );
    Redux::set_help_tab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( 'Send us a mail by using our item support form.', 'annie' );
    Redux::set_help_sidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */

    // ACTUAL DECLARATION OF SECTIONS
                Redux::setSection( $opt_name, array(
                    'title'  => esc_html__( 'General Settings', 'annie' ),
                    'desc'   => esc_html__( '', 'annie' ),
                    'icon'   => 'el-icon-home-alt',
                    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
                    'fields' => array(
					
					
					array(
								'id' => 'notice_ajax_loading',
								'type' => 'info',
								'notice' => true,
								'style' => 'success',
								'title' => esc_html__('Preloader, Scroll Bar & Content Protector', 'annie'),
								'desc' => esc_html__('Enable/ Disable Preloader, Scroll Bar & Content Protector  of your site.', 'annie')
						),
						
						array(
								'id' => 'content_protector',
								'type' => 'button_set',
								'title' => esc_attr__('Content Protector', 'annie'),
								'subtitle' => esc_attr__('Not affected for the logged in user.', 'annie'),
								'desc' => '',
								'options' => array(
										'st1'=> esc_html__('Disable', 'annie'),
										'st2' => esc_html__('Enable', 'annie'),
								),
								'default'  => 'st1'
						),

						array(
							'id' => 'scrollbar_opt',
							'type' => 'button_set',
							'title' => esc_attr__('Scrollbar', 'annie'),
							'subtitle' => esc_attr__('Enable/ Disable site scrollbar.', 'annie'),
							'desc' => '',
							'options' => array(
									'st1'=> esc_html__('Disable', 'annie'),
									'st2' => esc_html__('Enable', 'annie'),
							),
							'default'  => 'st1'
						),
						
						array(
								'id' => 'site_preloader',
								'type' => 'button_set',
								'title' => esc_attr__('Preloader', 'annie'),
								'subtitle' => esc_attr__('Enable/ Disable site preloader.', 'annie'),
								'desc' => '',
								'options' => array(
										'st1'=> esc_html__('Enable', 'annie'),
										'st2' => esc_html__('Disable', 'annie'),
								),
								'default'  => 'st1'
						),
					
					array(
			                'id' => 'notice_header_logo',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => esc_html__('Site Logo Options', 'annie'),
			                'desc' => esc_html__('', 'annie')
			         ),
					array(
							'id' => 'textlogo',
							'type' => 'button_set',
							'title' => esc_html__('Header Logo', 'annie'),
							'subtitle' => esc_html__('', 'annie'),
							'desc' => '',
							'options' => array(
									'st1'=> esc_html__('Disable', 'annie'),
									'st2' => esc_html__('Enable', 'annie'),
									
							),
							'default'  => 'st1'
					),
					
					array(
							'id' => 'sitetitle_opt',
							'type' => 'button_set',
							'title' => esc_html__('Site Ttile & Tagline', 'annie'),
							'subtitle' => esc_html__('', 'annie'),
							'desc' => '',
							'options' => array(
									'st1'=> esc_html__('Enable', 'annie'),
									'st2' => esc_html__('Disable', 'annie'),
							),
							'default'  => 'st1',
							'required' => array('textlogo', '=' , 'st2')
					),
					 
					array(
							'id' => 'logopic',
							'type' => 'media',
							'compiler' => 'true',
							'title' => esc_html__('Logo Image', 'annie'),
							'subtitle' => esc_html__('Image Size 150x80', 'annie'),
							'required' => array('textlogo', '=' , 'st2')
					),
					
					$fields = array(
							'id'       => 'opt_logo_dimensions',
							'type'     => 'dimensions',
							'units'    => array('em','px','%'),
							'output' => array('.logo-holder img'),
							'title'    => esc_html__('Logo Dimensions', 'annie'),
							'subtitle' => esc_html__('', 'annie'),
							'desc'     => esc_html__('Optional', 'annie'),
							'default'  => array(
								'Width'   => '110', 
								'Height'  => '22'
							),
							'required' => array('textlogo', '=' , 'st2')
				    ),	

					)
               ) );
			   
				 Redux::setSection( $opt_name, array(
                    'icon'   => 'el-icon-cogs',
                    'title'  => esc_html__( 'Page Settings', 'annie' ),
                    'fields' => array(		
					array(
							'id' => 'header-animate',
							'type' => 'info',
		                    'notice' => true,
		                    'style' => 'info',
							'title' => esc_html__('Page Animation Option', 'annie'),
							
					),	
			        array(
							'id' => 'index-header-animate',
							'type' => 'button_set',
							'title' => esc_html__('Header Animate Style', 'annie'),
							'subtitle' => esc_html__('Enable/Disable header section animate style for blog single, archives, category, tag & search page.', 'annie'),
							'default'  => 'no',
							'options' => array(
									'yes'=> esc_html__('Enable', 'annie'),
									'no'=> esc_html__('Disable', 'annie'),
							),
					),	
										
			        array(
							'id' => 'index-content-animate',
							'type' => 'button_set',
							'title' => esc_html__('Content Animate Style', 'annie'),
							'subtitle' => esc_html__('Enable/Disable content section animate style for pages, blog single, archives, category, tag & search page.', 'annie'),
							'default'  => 'no',
							'options' => array(
									'yes'=> esc_html__('Enable', 'annie'),
									'no'=> esc_html__('Disable', 'annie'),
							),
					),	
					
			        array(
							'id' => 'header-error',
							'type' => 'info',
		                    'notice' => true,
		                    'style' => 'info',
							'title' => esc_html__('404 Error Page Option', 'annie'),
							
					),															
					array(
							'id' => 'error-page-title',
							'type' => 'text',
							'title' => esc_html__('Title Text', 'annie'),
							'subtitle' => esc_html__('Change/Repalce "404" text here.', 'annie'),
							'default' => '',
							
					),	
					array(
							'id' => 'error-page-sbtitle',
							'type' => 'text',
							'title' => esc_html__('Subtitle Text', 'annie'),
							'subtitle' => esc_html__('Change/Repalce "Page Error" text here.', 'annie'),
							'default' => '',
							
					),					
									
					
                    )
                ));				   
			   
				
				Redux::setSection( $opt_name, array(
                    'icon'   => 'el-icon-bullhorn',
                    'title'  => esc_html__( 'Blog Settings', 'annie' ),
                    'fields' => array(
																
					array(
							'id' => 'blog-page-title',
							'type' => 'text',
							'title' => esc_html__('Blog Title Text', 'annie'),
							'subtitle' => esc_html__('Insert blog page header title text here.', 'annie'),
							'required' => array('index-header-show', '=' , 'yes')
							
					),					
					array(
							'id' => 'blog-page-subtitle',
							'type' => 'text',
							'title' => esc_html__('Blog Subtitle Text', 'annie'),
							'subtitle' => esc_html__('Insert blog page header subtitle text here for blog single, archives, category, tag & search page.', 'annie'),
							'required' => array('index-header-show', '=' , 'yes')
							
					),				
			        
					array(
			                'id' => 'notice_blog-scroll_swipe_translation',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => esc_html__('Translation Options', 'annie'),
			                'desc' => esc_html__('Default Text Translate Here.', 'annie'),
			        ),					
					array(
							'id' => 'blog-read-more',
							'type' => 'text',
							'title' => __('Read More Text', 'annie'),
							'subtitle' => __('Change/Repalce blog post "Read More" text here.', 'annie'),
							'default' => '',
							
					),						
					array(
							'id' => 'arch-page-title',
							'type' => 'text',
							'title' => esc_html__('Archive Page Title', 'annie'),
							'subtitle' => esc_html__('Write header title for blog archive page here. Ex: Archive : ', 'annie'),
							'default' => '',
					),	
					array(
							'id' => 'cat-page-title',
							'type' => 'text',
							'title' => esc_html__('Category Page Title', 'annie'),
							'subtitle' => esc_html__('Write header title for blog category page here. Ex: Category : ', 'annie'),
							'default' => '',
					),	
	
					array(
							'id' => 'tag-page-title',
							'type' => 'text',
							'title' => esc_html__('Tag Page Title', 'annie'),
							'subtitle' => esc_html__('Write header title for blog tag page here. Ex: Tag : ', 'annie'),
							'default' => '',
					),						

					array(
							'id' => 'src-page-title',
							'type' => 'text',
							'title' => esc_html__('Search Page Title', 'annie'),
							'subtitle' => esc_html__('Write header title for blog search page title here. Ex: Search Results for :', 'annie'),
							'default' => '',
					),					
					
                    )
                ) );
				Redux::setSection( $opt_name, array(
                    'icon'   => 'el-icon-brush',
                    'title'  => esc_html__( 'Styling', 'annie' ),
                    'fields' => array(
						
						array(
			                'id' => 'notice_header_theme_color',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => esc_html__('Color Scheme Options', 'annie'),
			                'desc' => esc_html__('Choose theme color scheme style.', 'annie')
						),					
						array(
							'id' => 'colorstyle',
							'type' => 'button_set',
							'title' => esc_html__('Color Scheme', 'annie'),
							'subtitle' => esc_html__('Choose theme color scheme style.', 'annie'),
							'default'  => 'no',
							'options' => array(
							    'st1'=> esc_html__('Dark Version', 'annie'),
								'st2'=> esc_html__('Light Version', 'annie'),
							),	
							'default'  => 'st1'							
						),
						
						array(
							'id' => 'notice_site_base_color',
							'type' => 'info',
							'notice' => true,
							'style' => 'success',
							'title' => esc_html__('Theme Base Colors.', 'annie'),
							'desc' => esc_html__('', 'annie'),
						),
						
						array(
							'id'       => 'opt_theme_style_body',
							'type'     => 'color',
							'title'    => esc_html__( 'Body Background', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'output'    => array(
								'background-color' => 'body', 
							),
						),
						
						array(
							'id' => 'notice_sidebar_image',
							'type' => 'info',
							'notice' => true,
							'style' => 'success',
							'title' => esc_html__('Sidebar Navigation', 'annie'),
							'desc' => esc_html__('Sidebar Navigation Options.', 'annie')
						),
						
						array(
							'id'       => 'opt_theme_nav_back',
							'type'     => 'color',
							'title'    => esc_html__( 'Navigation Background', 'annie' ),
							'subtitle' => esc_html__( 'Sidebar Navigation background color.', 'annie' ),
							'output'    => array(
								'background' => '.annie-aside', 
							),
						),
						
						array(
							'id' => 'sidebar_back_img',
							'type' => 'media',
							'title' => esc_html__('Background Image', 'annie'),
							'subtitle' => esc_html__('', 'annie'),
						),
						
						array(
							'id'       => 'sidebar_back_img_overlay',
							'type'     => 'color_rgba',
							'title'    => esc_html__( 'Overlay Color', 'annie' ),
							'subtitle' => esc_html__( 'Required', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
						),
						
						array(
							'id'       => 'sidebar_back_menu_border_color',
							'type'     => 'color_rgba',
							'title'    => esc_html__( 'Menu Item Border Color', 'annie' ),
							'subtitle' => esc_html__( 'Required', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
						),
						
						array(
							'id'       => 'opt_theme_res_hamburger_icon_backcolor',
							'type'     => 'color',
							'title'    => esc_html__( 'Responsive Toggle Icon Background', 'bauen' ),
							'subtitle' => esc_html__( '', 'bauen' ),
							'desc'     => esc_html__( '', 'bauen' ),
							'output'    => array(
								'background' => '.annie-nav-toggle', 
							),
						),
						
						array(
							'id'       => 'opt_theme_res_hamburger_icon_color',
							'type'     => 'color',
							'title'    => esc_html__( 'Responsive Toggle Icon Color', 'bauen' ),
							'subtitle' => esc_html__( '', 'bauen' ),
							'desc'     => esc_html__( '', 'bauen' ),
							'output'    => array(
								'background' => '.annie-nav-toggle.active i::before, .annie-nav-toggle.active i::after,.annie-nav-toggle i::before, .annie-nav-toggle i::after, .annie-nav-toggle i', 
								'color' => '.annie-nav-toggle i', 
							),
						),
						
						array(
							'id'       => 'opt_theme_side_social_icon_back',
							'type'     => 'color_rgba',
							'title'    => esc_html__( 'Social Icon Background', 'bauen' ),
							'subtitle' => esc_html__( '', 'bauen' ),
							'desc'     => esc_html__( '', 'bauen' ),
							'output'    => array(
								'background' => '.annie-aside .annie-footer ul li', 
							),
						),
						
						array(
							'id'       => 'opt_theme_side_social_icon_color',
							'type'     => 'color',
							'title'    => esc_html__( 'Social Icon Color', 'bauen' ),
							'subtitle' => esc_html__( '', 'bauen' ),
							'desc'     => esc_html__( '', 'bauen' ),
							'output'    => array(
								'color' => '.annie-footer a, .annie-footer a i', 
							),
						),
						
						array(
							'id' => 'notice_site_global_preloader_opt',
							'type' => 'info',
							'notice' => true,
							'style' => 'success',
							'title' => esc_html__('Preloader Options', 'annie'),
							'desc' => esc_html__('Site Preloader options.', 'annie'),
						),
						
						array(
							'id'       => 'opt_theme_style_preloader',
							'type'     => 'color',
							'title'    => esc_html__( 'Preloader Background', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'output'    => array(
								'background' => '.preloader-bg, #preloader', 
							),
						),
						
						array(
							'id'       => 'opt_theme_site_theme_preloader_progress_bar',
							'type'     => 'color_rgba',
							'title'    => esc_html__( 'Progress Bar Background Color', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
							'output'    => array(
								'border-color' => '.loader', 
							),
						),
						
						array(
							'id'       => 'opt_theme_site_theme_preloader_progress_bar_active',
							'type'     => 'color',
							'title'    => esc_html__( 'Progress Bar Active Background/ Border Color', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
							'output'    => array(
								'border-top-color' => '.loader span', 
							),
						),
						
						array(
							'id' => 'notice_site_global_footer_opt',
							'type' => 'info',
							'notice' => true,
							'style' => 'success',
							'title' => esc_html__('Footer', 'annie'),
							'desc' => esc_html__('Site Footer Background options.', 'annie'),
						),
						
						array(
							'id'       => 'opt_site_footer_back_color',
							'type'     => 'color',
							'title'    => esc_html__( 'Background Color', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
							'output'    => array(
								'background' => '#annie-footer', 
							),
						),
						
						array(
							'id' => 'notice_site_theme_scroll_to_top',
							'type' => 'info',
							'notice' => true,
							'style' => 'success',
							'title' => esc_html__('Scroll To Top Button Options.', 'annie'),
							'desc' => esc_html__('', 'annie'),
						),
						
						array(
							'id'       => 'opt_theme_site_to_top_progress_bar',
							'type'     => 'color_rgba',
							'title'    => esc_html__( 'Progress Bar Color', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
						),
						array(
							'id'       =>'opt_theme_site_theme_scroll_to_top_back_active',
							'type'     => 'color',
							'title'    => esc_html__( 'Progress Bar Active Color', 'annie' ),
							'subtitle' => esc_html__( '', 'annie' ),
							'desc'     => esc_html__( '', 'annie' ),
							'output'    => array(
								'stroke' => '.progress-wrap svg.progress-circle path', 
								'color' => '.progress-wrap::after', 
							),
						),
						
						
					)
            ) );
            Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-icon-smiley-alt',
                    'title'  => esc_html__( 'Social Icons Settings', 'annie' ),
                    'fields' => array(									
						
			        array(
							'id' => 'social-icon-site',
							'type' => 'button_set',
							'title' => esc_html__('Social Icon Navigation Sidebar', 'annie'),
							'default'  => 'no',
							'options' => array(
								'yes'=> esc_html__('Enable', 'annie'),	
								'no'=> esc_html__('Disable', 'annie'),	
							),
					),
			        					
					array(
						'id'        => 'facebook',
						'type'      => 'text',
						'title'     => esc_html__('Facebook Link', 'annie'),
						'subtitle'  => esc_html__('Insert facebook url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),

					 array(
						'id'        => 'twitter',
						'type'      => 'text',
						'title'     => esc_html__('Twitter Link', 'annie'),
						'subtitle'  => esc_html__('Insert twitter url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),

					 array(
						'id'        => 'linkedin',
						'type'      => 'text',
						'title'     => esc_html__('LinkedIn Link', 'annie'),
						'subtitle'  => esc_html__('Insert linkedin url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),

					array(
						'id'        => 'instagram',
						'type'      => 'text',
						'title'     => esc_html__('Instagram Link', 'annie'),
						'subtitle'  => esc_html__('Insert instagram url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),
					
					array(
						'id'        => 'tiktok',
						'type'      => 'text',
						'title'     => esc_html__('Tiktok Link', 'annie'),
						'subtitle'  => esc_html__('Insert Tiktok url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),

					 array(
						'id'        => 'pinterest',
						'type'      => 'text',
						'title'     => esc_html__('Pinterest Link', 'annie'),
						'subtitle'  => esc_html__('Insert pinterest url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),
					 array(
						'id'        => 'youtube',
						'type'      => 'text',
						'title'     => esc_html__('Youtube Link', 'annie'),
						'subtitle'  => esc_html__('Insert youtube url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),	
					 array(
						'id'        => 'vimeo',
						'type'      => 'text',
						'title'     => esc_html__('Vimeo Link', 'annie'),
						'subtitle'  => esc_html__('Insert vimeo url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),	
					 array(
						'id'        => 'soundcloud',
						'type'      => 'text',
						'title'     => esc_html__('Soundcloud link', 'annie'),
						'subtitle'  => esc_html__('Insert soundcloud url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),			

					 array(
						'id'        => 'skype',
						'type'      => 'text',
						'title'     => esc_html__('Skype Link', 'annie'),
						'subtitle'  => esc_html__('Insert skype url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),
					 array(
						'id'        => 'dribbble',
						'type'      => 'text',
						'title'     => esc_html__('Dribbble Link', 'annie'),
						'subtitle'  => esc_html__('Insert dribbble url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),

					 array(
						'id'        => 'dropbox',
						'type'      => 'text',
						'title'     => esc_html__('Dropbox Link', 'annie'),
						'subtitle'  => esc_html__('Insert dropbox url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),			
					 array(
						'id'        => 'github',
						'type'      => 'text',
						'title'     => esc_html__('Github Link:', 'annie'),
						'subtitle'  => esc_html__('Insert github url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),
					
					array(
						'id'        => 'tumblr',
						'type'      => 'text',
						'title'     => esc_html__('Tumblr Link:', 'annie'),
						'subtitle'  => esc_html__('Insert tumblr url here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),

					 array(
						'id'        => 'email',
						'type'      => 'text',
						'title'     => esc_html__('E-mail:', 'annie'),
						'subtitle'  => esc_html__('Insert e-mail address here.', 'annie'),
						'dece'      => esc_html__('','annie'),
						'validate'  => '',
						'required' => array('social-icon-site', '=' , 'yes')
					),           	
							)
				));	
			
			Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-icon-cog',
                    'title'  => __( 'Translate Options', 'annie' ),
                    'fields' => array(
					
										
					array(
							'id' => 'translet_opt_6',
							'type' => 'text',
							'title' => esc_html__('Type & Hit Enter...', 'annie'),
							'subtitle' => esc_html__('Search Widget Placeholder Text.', 'annie'),
					),
					
					
					array(
							'id' => 'translet_opt_10',
							'type' => 'text',
							'title' => esc_html__('One thought on', 'annie'),
							'subtitle' => esc_html__('Post Comment Section.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_11',
							'type' => 'text',
							'title' => esc_html__('thought on', 'annie'),
							'subtitle' => esc_html__('Post Comment Section.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_12',
							'type' => 'text',
							'title' => esc_html__('thoughts on', 'annie'),
							'subtitle' => esc_html__('Post Comment Section.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_13',
							'type' => 'text',
							'title' => esc_html__('Comments are closed.', 'annie'),
							'subtitle' => esc_html__('Post Comment Section.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_14',
							'type' => 'text',
							'title' => esc_html__('Your Name', 'annie'),
							'subtitle' => esc_html__('Post Comment Section Form.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_15',
							'type' => 'text',
							'title' => esc_html__('Your Email', 'annie'),
							'subtitle' => esc_html__('Post Comment Section Form.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_16',
							'type' => 'text',
							'title' => esc_html__('Your Comment', 'annie'),
							'subtitle' => esc_html__('Post Comment Section Form.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_17',
							'type' => 'text',
							'title' => esc_html__('Leave a Comment', 'annie'),
							'subtitle' => esc_html__('Post Comment Section Form.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_s_t',
							'type' => 'text',
							'title' => esc_html__('Results for', 'annie'),
							'subtitle' => esc_html__('Post Search Page.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_23',
							'type' => 'text',
							'title' => esc_html__('No Post Found', 'annie'),
							'subtitle' => esc_html__('Post Search Page.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_24',
							'type' => 'text',
							'title' => esc_html__('Please Search Again.', 'annie'),
							'subtitle' => esc_html__('Post Search Page.', 'annie'),
					),
					
					array(
							'id' => 'translet_opt_7',
							'type' => 'text',
							'title' => esc_html__('Search...', 'annie'),
							'subtitle' => esc_html__('Search Page Form Placeholder Text.', 'annie'),
					),
					
					)
                ) );

            Redux::setSection( $opt_name, array(
                    'icon'   => 'el-icon-text-width',
                    'title'  => __( 'Typography', 'annie' ),
                    'fields' => array(     
						array(
                            'id'          => 'typo_body',
                            'type'        => 'typography', 
                            'title'       => __('Body', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('body'),
                            'units'       =>'px',
                            'line-height'       =>false,
                            'subtitle'    => esc_html__('Specify the Body Text font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						array(
			                'id' => 'notice_critical11',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => __('Entry Headings', 'annie'),
			                'desc' => __('Entry Headings in posts/pages', 'annie')
			            ),								
                        array(
                            'id'          => 'typography-h1',
                            'type'        => 'typography', 
                            'title'       => __('H1', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('h1'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the Heading font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),	
                        array(
                            'id'          => 'typography-h2',
                            'type'        => 'typography', 
                            'title'       => __('H2', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('h2'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the Heading font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),      
                        ),
                        array(
                            'id'          => 'typography-h3',
                            'type'        => 'typography', 
                            'title'       => __('H3', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('h3'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the Heading font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),	
                        array(
                            'id'          => 'typography-h4',
                            'type'        => 'typography', 
                            'title'       => __('H4', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('h4'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the Heading font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),                        	
                        array(
                            'id'          => 'typography-h5',
                            'type'        => 'typography', 
                            'title'       => __('H5', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('h5'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the Heading font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),	
                        array(
                            'id'          => 'typography-h6',
                            'type'        => 'typography', 
                            'title'       => __('H6', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('h6'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the Heading font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),	
						  
						array(
			                'id' => 'notice_critical13',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => __('Page', 'annie'),
			                'desc' => __('', 'annie')
			            ),
                        array(
                            'id'          => 'typography-pgtl',
                            'type'        => 'typography', 
                            'title'       => __('Page Title', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-heading'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the page title font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),						

                        array(
                            'id'          => 'typography-pgcontentl',
                            'type'        => 'typography', 
                            'title'       => __('Content', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('p, .page-content p'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the page content text font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),							
						),						
                        array(
                            'id'          => 'typography-pgsecwdtl',
                            'type'        => 'typography', 
                            'title'       => __('Sidebar Widget Title', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-sidebar-block .annie-sidebar-block-title'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the page section title font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),							
						), 						
						array(
			                'id' => 'notice_critical14',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => __('Post', 'annie'),
			                'desc' => __('', 'annie')
			            ),	
                        array(
                            'id'          => 'typography-bltl',
                            'type'        => 'typography', 
                            'title'       => __('Title', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.single-post .annie-post-heading'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the blog post title font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),							
						),						
                        array(
                            'id'          => 'typography-blcon',
                            'type'        => 'typography', 
                            'title'       => __('Content', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.post-content p, .comment-text p'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the blog post content font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),							
						),	
						array(
			                'id' => 'notice_critical1_permalink1',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => __('Permalink', 'annie'),
			                'desc' => __('', 'annie')
			            ),	
                        array(
                            'id'          => 'typography-lnurl',
                            'type'        => 'typography', 
                            'title'       => __('Link URL', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('a'),
                            'units'       =>'px',
                            'subtitle'    => __('Specify the permalink link url font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),							
						),		
						array(
                            'id'          => 'typography-a-hover',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Link URL Hover', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('a:focus, a:hover'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Specify the permalink font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),							
						array(
			                'id' => 'notice_critical1_navmenu',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => __('Sidebar Menu', 'annie'),
			                'desc' => __('', 'annie')
			            ),		
						array(
                            'id'          => 'typography_site_title',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Site Title', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-aside .annie-logo a'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						
						array(
                            'id'          => 'typography_site_tagline',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Site Tag Line', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-aside .annie-logo a span'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						
						array(
                            'id'          => 'typography-a-navmenu',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Menu Item', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-aside .annie-main-menu > ul > li > a, .annie-aside .annie-main-menu > ul > li.open > a'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Specify the permalink font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						array(
                            'id'          => 'typography-a-navmenumain-hover',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Menu Item Hover', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-aside .annie-main-menu > ul > li > a:hover, .annie-aside .annie-main-menu > ul > li.open:hover > a'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Specify the permalink font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						array(
                            'id'          => 'typography-a-navmenu-hover-main',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Sub Menu Item', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-aside .annie-main-menu ul ul li a'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Specify the permalink font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						
						array(
                            'id'          => 'typography-a-navmenu-hover',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Sub Menu Item Hover', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.annie-aside .annie-main-menu ul ul li:hover > a, .annie-aside .annie-main-menu ul ul li.open > a, .annie-aside .annie-main-menu ul ul li.active > a'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('Specify the permalink font properties.', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),

						array(
			                'id' => 'notice_critical1_footer',
			                'type' => 'info',
			                'notice' => true,
			                'style' => 'success',
			                'title' => __('Footer Options', 'annie'),
			                'desc' => __('', 'annie')
			            ),		
						array(
                            'id'          => 'typography_footer_site_title',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Site Title', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('.footer_tag_line'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						
						array(
                            'id'          => 'typography_footer_site_tags_line',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Site Tag Line', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('body #annie-footer h2 span'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						
						array(
                            'id'          => 'typography_footer_copyright',
                            'type'        => 'typography', 
                            'title'       => esc_html__('Copyright Text', 'annie'),
                            'google'      => true, 
                            'font-backup' => false,
                            'output'      => array('body .footer_copyright_info'),
                            'units'       =>'px',
                            'subtitle'    => esc_html__('', 'annie'),
                            'default'     => array(
                            'color'       => false,
                            'font-style'  => false,
                            'font-family' => false,
                            'google'      => true,
                            'font-size'   => false,
                            'line-height' => false,
                            ),
						),
						
					)
               ) );					

				 Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-icon-th-large',
                    'title'  => esc_html__( 'Footer Settings', 'annie' ),
                    'fields' => array(
					
					array(
							'id' => 'theme-cus-copy',
							'type' => 'info',
		                    'notice' => true,
		                    'style' => 'info',
							'title' => esc_html__('Copyright Text', 'annie'),
							'desc' => esc_html__('', 'annie')
							
					  ),
					
					array(
							'id' => 'copyright',
							'type' => 'editor',
							'wpautop'=>true,
							'compiler' => 'true',
							'title' => esc_html__('Copyright', 'annie'),
							'subtitle' => esc_html__('Insert  copyright text here. Date shortcode [annie_year]', 'annie'),
							'default'          => '&copy; [annie_year] Annie by webRedox',
							'args'   => array(
								'teeny'            => true,
								'textarea_rows'    => 10
							)
					),
					
					array(
							'id' => 'menu_copy_opt',
							'type' => 'button_set',
							'title' => esc_html__('Menu Copyright Area', 'annie'),
							'subtitle' => esc_html__('Enable/ Disable copyright area from the Menu.', 'annie'),
							'default'  => 'no',
							'options' => array(
							        'st1'=> esc_html__('Enable', 'annie'),
									'st2'=> esc_html__('Disable', 'annie'),
							),	
							'default'  => 'st1'							
					),
					
					array(
							'id' => 'footer_sitetitle_opt',
							'type' => 'button_set',
							'title' => esc_html__('Footer Site Ttile & Tagline', 'annie'),
							'subtitle' => esc_html__('', 'annie'),
							'desc' => '',
							'options' => array(
									'st1'=> esc_html__('Enable', 'annie'),
									'st2' => esc_html__('Disable', 'annie'),
							),
							'default'  => 'st1',
					),

					array(
						'id' => 'footer_copyright_opt',
						'type' => 'button_set',
						'title' => esc_html__('Footer Copyright Area', 'annie'),
						'subtitle' => esc_html__('', 'annie'),
						'desc' => '',
						'options' => array(
								'st1'=> esc_html__('Enable', 'annie'),
								'st2' => esc_html__('Disable', 'annie'),
						),
						'default'  => 'st1',
					),
					
					array(
						'id' => 'enable_scroll_top',
						'type' => 'button_set',
						'title' => esc_attr__('Scroll To Top Button', 'annie'),
						'subtitle' => esc_attr__('', 'annie'),
						'desc' => '',
						'options' => array(
							'st1'=> esc_html__('Enable', 'annie'),
							'st2' => esc_html__('Disable', 'annie'),
						),
						'default'  => 'st1'
					),
					
					
					)
                ) );
				
				Redux::setSection( $opt_name, array(
                    'icon'   => 'el-icon-key',
                    'title'  => esc_html__( 'Documentation', 'annie' ),
                    'fields' => array(										
					array(
							'id' => 'docs',
							'type' => 'info',
		                    'notice' => true,
		                    'style' => 'info',
							'title' => esc_html__('Annie Theme Documentation', 'annie'),
							'desc' => __('<a href="https://webredox.net/doc/annie/" target="_blank">Click Here</a> To get the theme documentation.', 'annie')
							
					),	
			
					)
                ));
				
				
    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $return['error'] = $field;
                $field['msg']    = 'your custom error message';
            }

            if ( $warning == true ) {
                $return['warning'] = $field;
                $field['msg']      = 'your custom warning message';
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => esc_html__( 'Section via hook', 'annie' ),
                'desc'   => esc_html__( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'annie' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    /**
     * Removes the demo link and the notice of integrated demo from the redux-annie plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }

