<?php $annie_options = get_option('annie'); ?>
<?php if($annie_options['index-header-animate'] == 'yes') { 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-post-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-post-heading";
 } 
if($annie_options['index-content-animate'] == 'yes') {
$annie_content_class ='animate-box fadeInUp animated';
}
 else {
$annie_content_animate ="";
$annie_content_class ="";
 }
 ;?>
<?php if(have_posts()) : while ( have_posts() ) : the_post();?>
<div class="annie-post">
                <div class="container-fluid">
				<?php if (has_post_thumbnail( $post->ID ) ):
				$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
                    <div class="row">
                        <div class="col-md-12 image-content animate-box fadeInUp animated" data-animate-effect="fadeInUp"> <img src="<?php echo esc_url($annie_image[0]);?>" class="img-fluid mb-30 en-blog-img" alt="<?php the_title_attribute();?>"> </div>
                    </div>
				<?php endif;?>
                    <div class="row">
                        <div class="col-md-12 text-center"> <span class="heading-meta"><?php the_category(', '); ?></span>
                            <h2 class="<?php echo esc_attr($annie_title_class);?>" <?php echo esc_attr($annie_title_animate);?>><?php the_title();?></h2> </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 <?php echo esc_attr($annie_content_class);?>">
                            <?php the_content();
								wp_link_pages( array(
								'before'      => '<div class="page-links post-details-url">',
								'after'       => '</div>',
								'link_before' => '',
								'link_after'  => '',
								'pagelink'    => '%',
								'separator'   => '',
								) );
							?>	
                        </div>
                    </div>
                    <?php if ( comments_open() || get_comments_number() ) { ?>				
					<?php comments_template();?>
					<?php }?>
                </div>
            </div>
<?php endwhile;  endif; wp_reset_postdata(); ?>