<?php $annie_options = get_option('annie'); ?>
<?php
/*Template Name:Blog Page*/
 get_header();
 ?>
	<?php if(get_post_meta($post->ID,'rnr_wrblog_pagetype',true)=='st2'){ ?> 
        <?php get_template_part('template-parts/blog/right');?>
	<?php } else  { ?>
		<?php get_template_part('template-parts/blog/default');?>
	<?php }?>
<?php get_footer(); ?>
       
  

