<?php $annie_options = get_option('annie'); ?>
<?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>
<?php if(get_post_meta($post->ID,'rnr_page_header_block_animate',true)=='yes'){ 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
<!-- Blog -->
            <div class="annie-blog">
                <div class="container-fluid">
                    <?php if(get_post_meta($post->ID,'rnr_page_header_block',true)=='no'){ ?>
					<?php } else { ?>	
						<div class="row">
						   <div class="col-md-12 text-center"> 
						   <?php if (( get_post_meta($post->ID,'rnr_page_right_block_header_subtitle',true))):?>
							<span class="heading-meta"><?php echo esc_html(get_post_meta($post->ID,'rnr_page_right_block_header_subtitle',true)); ?></span>
						   <?php endif; ?>
							<h2 class="<?php echo esc_attr($annie_title_class);?>"  <?php echo esc_attr($annie_title_animate);?>><?php if (( get_post_meta($post->ID,'rnr_page_right_block_header_title',true))):?><?php echo esc_html(get_post_meta($post->ID,'rnr_page_right_block_header_title',true)); ?><?php else: ?><?php the_title();?><?php endif;?></h2> 
							</div>
						</div>
					<?php } ;?>
						<?php if (has_post_thumbnail( $post->ID ) ):
						$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
						<div class="row">
						<div class="col-md-12 animate-box" data-animate-effect="zoomInDown"> <img src="<?php echo esc_url($annie_image[0]);?>" alt="<?php the_title_attribute();?>" class="img-fluid mb-30"> </div>
						</div>
						<?php endif;?>
					<div class="card-columns">
									<?php
									global $post, $post_id;;
									$annie_showpost= get_post_meta($post->ID, 'rnr_blog-post-show', true);$annie_categoryname=get_post_meta($post->ID, 'rnr_blog-post-cat', true);$annie_paged=(get_query_var('paged'))?get_query_var('paged'):1;
									$annie_loop = new WP_Query( array( 'post_type' => 'post', 'posts_per_page'=>$annie_showpost, 'category_name'=> $annie_categoryname, 'paged'=>$annie_paged ) ); ?>
									<?php while ( $annie_loop->have_posts() ) : $annie_loop->the_post();?>
    <div class="card <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            
				<?php if (has_post_thumbnail( $post->ID ) ):
				$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
                <a href="<?php the_permalink();?>" class="card-img"><img src="<?php echo esc_url($annie_image[0]);?>" class="img-fluid" alt="<?php the_title_attribute();?>"></a>
				<?php endif;?>
				<div class="card-body">
                    <div class="desc"> <span><?php the_time( get_option( 'date_format' ) ); ?> | <?php the_category(', '); ?></span>
                    <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                    <?php if( wp_link_pages('echo=0') ): ?>										
					<?php the_content();
					wp_link_pages( array(
					'before'      => '<div class="page-links">',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '%',
					'separator'   => '',
					) );
					?>
					<?php else : ?>
                    <?php the_excerpt(); ?>
					<?php endif;?>
                    </div>
                    </div>
            
        </div>
    </div>
<?php endwhile; ?>
<?php wp_reset_postdata();?>
</div>
<?php if (function_exists("annie_pagination")) {
annie_pagination($annie_loop->max_num_pages);
} ?>
                </div>
            </div>