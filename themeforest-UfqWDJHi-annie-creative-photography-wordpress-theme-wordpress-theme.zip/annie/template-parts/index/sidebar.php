<?php $annie_options = get_option('annie'); ?>	
<?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>				
<div class="row">
<div class="col-md-8">
<div class="row">
<?php global $post, $post_id;?>
<?php while ( have_posts() ) : the_post();?>
    <div class="col-md-12 <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="blog-entry">
				<?php if (has_post_thumbnail( $post->ID ) ):
				$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
                <a href="<?php the_permalink();?>" class="blog-img"><img src="<?php echo esc_url($annie_image[0]);?>" class="img-fluid" alt="<?php the_title_attribute();?>"></a>
				<?php endif;?>
                    <div class="desc"> <span><?php the_time( get_option( 'date_format' ) ); ?> | <?php the_category(', '); ?></span>
                    <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
					<?php if( wp_link_pages('echo=0') ): ?>										
					<?php the_content();
					wp_link_pages( array(
					'before'      => '<div class="page-links post-details-url">',
					'after'       => '</div>',
					'link_before' => '',
					'link_after'  => '',
					'pagelink'    => '%',
					'separator'   => '',
					) );
					?>
					<?php else : ?>
                    <?php the_excerpt(); ?>
					<?php endif;?>
                    </div>
            </div>
        </div>
    </div>
<?php endwhile; ?>
<?php wp_reset_postdata();?>  
<div class="hidden"><?php the_tags(); next_posts_link(); previous_posts_link();wp_link_pages();comment_form();paginate_comments_links();previous_comments_link(); wp_enqueue_script('comment-reply'); the_post_thumbnail();?></div>
</div>
<?php if (function_exists("annie_pagination")) {
annie_pagination($wp_query->max_num_pages);
} ;?>
</div>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<div class="col-md-4">
<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
<?php endif;?>
</div>
