<?php 
require (ANNIE_THEME_PATH . '/includes/core/ad/system-file.php');
require (ANNIE_THEME_PATH . '/includes/annie-options.php');
if ( class_exists( 'OCDI_Plugin' ) ) {
if (class_exists('WPBakeryVisualComposerAbstract')) {
require (ANNIE_THEME_PATH . '/includes/loader-all.php');
}
else {
require (ANNIE_THEME_PATH . '/includes/loader.php');
}
}
?>