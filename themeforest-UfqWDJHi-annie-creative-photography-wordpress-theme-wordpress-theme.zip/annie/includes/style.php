<?php
global $annie_options;
$annie_options = get_option('annie');
function annie_style() {
wp_enqueue_style('annie-main', (ANNIE_THEME_URL . '/style.css'));
wp_enqueue_style('annie-animate', (ANNIE_THEME_URL . '/includes/css/animate.css'));
wp_enqueue_style('et-lineicons', (ANNIE_THEME_URL . '/includes/css/et-lineicons.css'));
wp_enqueue_style('themify-icons', (ANNIE_THEME_URL . '/includes/css/themify-icons.css'));
wp_enqueue_style('bootstrap', (ANNIE_THEME_URL . '/includes/css/bootstrap.css'));
wp_enqueue_style('flexslider', (ANNIE_THEME_URL . '/includes/css/flexslider.css'));
wp_enqueue_style('fancybox', (ANNIE_THEME_URL . '/includes/css/fancybox.min.css'));
if (annie_AfterSetupTheme::return_thme_option('colorstyle')=='st2'){
wp_enqueue_style('annie-style', (ANNIE_THEME_URL . '/includes/css/style-light.css'));
} else {
wp_enqueue_style('annie-style', (ANNIE_THEME_URL . '/includes/css/style-dark.css'));
}
wp_enqueue_style('annie-map', (ANNIE_THEME_URL . '/includes/css/map.css'));
wp_enqueue_style('font-awesome-annie', (ANNIE_THEME_URL . '/includes/css/font-awesome.min.css'));
wp_enqueue_style('annie-yourstyle', (ANNIE_THEME_URL . '/includes/css/yourstyle.css'));

}
add_action('wp_enqueue_scripts', 'annie_style');

function annie_fonts_url() {
    $annie_font_url = '';
    
    if ( 'off' !== _x( 'on', 'Josefin font: on or off', 'annie' ) ) {
        $annie_font_url = add_query_arg( 'family','Josefin+Sans:300,400,600,700&display=swap' , "//fonts.googleapis.com/css" );
    }
    return $annie_font_url;
}

function annie_scripts() {
    wp_enqueue_style( 'annie_fonts', annie_fonts_url(), array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'annie_scripts' );

function annie_enqueue_custom_admin_style() {
wp_register_style( 'custom_wp_admin_css', (ANNIE_THEME_URL . '/includes/css/admin-style.css'), false, '1.0.0' );
wp_enqueue_style( 'custom_wp_admin_css' );
}
add_action( 'admin_enqueue_scripts', 'annie_enqueue_custom_admin_style' );