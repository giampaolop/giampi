<?php $annie_options = get_option('annie'); ?>

		<?php if($annie_options['index-content-animate'] == 'yes') {?>
		   <?php if(!empty($annie_options['index-content-animate-style'])): ?>
		   </div>
		   <?php else : ?>	
		   </div>
		   <?php endif;?>					
		<?php } else { ?>
		<?php } ?>	