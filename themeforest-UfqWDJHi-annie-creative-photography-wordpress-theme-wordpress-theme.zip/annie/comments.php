<?php $annie_options = get_option('annie'); ?>
<?php
if ( post_password_required() ) {
	return;
}
?>
<?php if ( have_comments() ) : ?>
	<?php
	global $annie_comment_meta_text, $annie_comment_meta_text2, $annie_comment_meta_text3;
	if(!empty($annie_options['translet_opt_10'])):
	$annie_comment_meta_text= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_10',''));;
	else: 
	$annie_comment_meta_text='One thought on';
	endif;
	if(!empty($annie_options['translet_opt_11'])):
	$annie_comment_meta_text2= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_11',''));;
	else: 
	$annie_comment_meta_text2='thought on';
	endif;
	if(!empty($annie_options['translet_opt_12'])):
	$annie_comment_meta_text3= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_12',''));;
	else: 
	$annie_comment_meta_text3='thoughts on';
	endif;
	?>
    <?php get_template_part('template-parts/animate/animate-div-start'); ?> 
	<div class="row">
	    <div class="col-md-12 col-sm-12">
	        <div class="clear" id="comment-list">
			    <div class="comments-area" id="comments">	
					<h2 class="comments-title">
						<?php
			$comment_count = get_comments_number();
			if ( 1 === $comment_count ) {
				printf(
					
					esc_html__( ''.$annie_comment_meta_text.' &ldquo;%1$s&rdquo;', 'annie' ),
					'<span>' . get_the_title() . '</span>'
				);
			} else {
				printf( 
					esc_html__( _nx( '%1$s '.$annie_comment_meta_text2.' &ldquo;%2$s&rdquo;', '%1$s '.$annie_comment_meta_text3.' &ldquo;%2$s&rdquo;', $comment_count, 'comments title', 'annie' ) ),
					number_format_i18n( $comment_count ),
					'<span>' . get_the_title() . '</span>'
				);
			}
			?>		
					</h2>

					<?php the_comments_navigation(); ?>
					
					<ol class="comment-list">			
						<?php
							wp_list_comments( array(
								'callback'   => 'annie_comment',
								'short_ping' => true,
							) );
						?>
					</ol><!-- .comment-list -->
		            <div class="clearfix"></div>
		
		            <?php the_comments_navigation();?>

					<?php if ( ! comments_open() ) : ?>
						<p class="no-comments">><?php if(!empty($annie_options['translet_opt_13'])):?><?php echo esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_13',''));?><?php else: ?><?php esc_html_e( 'Comments are closed.', 'annie' ); ?><?php endif;?></p>
					<?php endif; ?>

				</div>
			</div>
		</div>					
	</div>		
<?php get_template_part('template-parts/animate/animate-div-end'); ?> 
<?php endif; // Check for have_comments(). ?>
    <?php get_template_part('template-parts/animate/animate-div-start'); ?> 
    <div class="row">
        <div class="col-md-8">	
		 
			<?php 
			global $annie_comment_your_name, $annie_comment_your_email, $annie_comment_your_comment, $annie_comment_send_commen;
			if(!empty($annie_options['translet_opt_14'])):
			$annie_comment_your_name= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_14',''));;
			else: 
			$annie_comment_your_name='Your Name';
			endif;
			if(!empty($annie_options['translet_opt_15'])):
			$annie_comment_your_email= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_15',''));;
			else: 
			$annie_comment_your_email='Your Email';
			endif;
			if(!empty($annie_options['translet_opt_16'])):
			$annie_comment_your_comment= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_16',''));;
			else: 
			$annie_comment_your_comment='Your Comment';
			endif;
			if(!empty($annie_options['translet_opt_17'])):
			$annie_comment_send_comment= esc_html(annie_AfterSetupTheme::return_thme_option('translet_opt_17',''));;
			else: 
			$annie_comment_send_comment='Leave a Comment';
			endif;
			
			
			$annie_args = array(
				'fields' => apply_filters(
				'comment_form_default_fields', array(
					
					'author' =>'<div class="row"><div class="col-sm-6">' . '<input id="author"  placeholder="'. $annie_comment_your_name .'" name="author" type="text" value="' .
						esc_attr( $commenter['comment_author'] ) . '" size="40"/>'.
						
						'</div>'
						,
					'email'  => '<div class="col-sm-6">' . '<input id="email" placeholder="'.$annie_comment_your_email.'" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
						'" size="40"/>'  .
						
						'</div></div>',
					
				)
				),
				'comment_field' => '' .
				'<textarea id="comment" class="form-control" name="comment" cols="40" rows="7" placeholder="'.$annie_comment_your_comment.'" aria-required="true"></textarea>' .
				'',
				'title_reply' => '<h3 class="annie-contact-heading">'. $annie_comment_send_comment .'</h3>'
				
			); comment_form($annie_args); ?>
	
        </div>
    </div>
    <?php get_template_part('template-parts/animate/animate-div-end'); ?> 

