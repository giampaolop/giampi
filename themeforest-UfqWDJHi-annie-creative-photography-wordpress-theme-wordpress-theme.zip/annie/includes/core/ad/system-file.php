<?php 
require (ANNIE_THEME_PATH . '/includes/core/ac/_junk.php');
add_action('init', 'annie_register_menus');
?>