<?php $annie_options = get_option('annie'); ?>
<?php get_header();?>
<?php if(get_post_meta($post->ID,'rnr_post_widget_opt',true)=='st2'){ ?>
		<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
        <?php get_template_part('template-parts/index-details/widget');?>
		<?php else : ?>
		<?php get_template_part('template-parts/index-details/full');?>
		<?php endif;?>
<?php } else  { ?>
		<?php get_template_part('template-parts/index-details/full');?>
<?php }?>
<?php get_footer(); ?>