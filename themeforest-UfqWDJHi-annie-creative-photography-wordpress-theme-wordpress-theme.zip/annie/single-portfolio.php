<?php $annie_options = get_option('annie'); ?>
<?php get_header();?>
<?php if(have_posts()) : while ( have_posts() ) : the_post();?>
<?php if(get_post_meta($post->ID,'rnr_port_header_block_animate',true)=='yes'){ 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
	
                <?php if(get_post_meta($post->ID,'rnr_port_df_content_main',true)=='st2'){ ?>
				<?php if(get_post_meta($post->ID,'rnr_pagetype_container',true)=='st2'){ ?>
					<?php the_content();
							 wp_link_pages( array(
							'before'      => '<div class="page-links post-details-url">',
							'after'       => '</div>',
							'link_before' => '',
							'link_after'  => '',
							'pagelink'    => '%',
							'separator'   => '',
							) );													
					?>	
				<?php } else { ?>
					<div class="annie-post">
					<div class="container-fluid">
					<div class="page-content">
						<?php the_content();
							 wp_link_pages( array(
							'before'      => '<div class="page-links post-details-url">',
							'after'       => '</div>',
							'link_before' => '',
							'link_after'  => '',
							'pagelink'    => '%',
							'separator'   => '',
							) );													
							?>	
						</div>
					</div>
					</div>
				<?php } ;?>
				<?php } else { ?>
				<div class="annie-post">
				<div class="container-fluid">
				<?php if(get_post_meta($post->ID,'rnr_port_header_block',true)=='no'){ ?>
				<?php } else { ?>
                    <div class="row">
                        <div class="col-md-12 text-center"> 
							<?php if (( get_post_meta($post->ID,'rnr_port_right_block_header_subtitle',true))):?>
							<span class="heading-meta"><?php echo esc_html(get_post_meta($post->ID,'rnr_port_right_block_header_subtitle',true)); ?></span>
							<?php endif;?>
                            <h2 class="<?php echo esc_attr($annie_title_class);?>" <?php echo esc_attr($annie_title_animate);?>>
							<?php if (( get_post_meta($post->ID,'rnr_port_right_block_header_title',true))):?>
							<?php echo esc_html(get_post_meta($post->ID,'rnr_port_right_block_header_title',true)); ?>
							<?php else : ?>	 
							<?php the_title(); ?>
							<?php endif;?>	
							</h2> 
						</div>
                    </div>
					<?php $annie_images = rwmb_meta( 'rnr_portfolio_gallery_header_images','type=image&size=' );
					foreach ( $annie_images as $annie_image ){ ?>	
                    <div class="row">
                        <div class="col-md-12 image-content animate-box fadeInUp animated" data-animate-effect="fadeInUp"> <img src="<?php echo esc_url(($annie_image['url']));?>" class="img-fluid mb-30" alt="<?php echo esc_attr(($annie_image['title']));?>"> </div>
                    </div>
					<?php } ;?>
				<?php } ;?>
                    <div class="row">
                        <div class="col-md-12 animate-box fadeInUp animated" data-animate-effect="fadeInUp">
                            <?php the_content();?>
                        </div>
                    </div>
                </div>
                <!-- Gallery -->
                <div class="annie-gallery">
                    <div class="container-fluid">
                        <div class="row align-items-stretch annie-photos" id="annie-section-photos">
                            <div class="col-12">
                                <div class="row align-items-stretch">
								<?php $annie_images = rwmb_meta( 'rnr_portfolio_gallery_images','type=image&size=' );
								foreach ( $annie_images as $annie_image ){ ?>
                                    <div class="col-6 col-md-6 col-lg-4 animate-box" data-animate-effect="fadeInUp">
                                        <a href="<?php echo esc_url(($annie_image['url']));?>" class="d-block annie-photo-item" data-fancybox="gallery"> <img src="<?php echo esc_url(($annie_image['url']));?>" alt="<?php echo esc_attr(($annie_image['title']));?>" class="img-fluid">
                                            <div class="photo-text-more"> <span class="ti-search"></span> </div>
                                        </a>
                                    </div>
                                 <?php } ;?>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				</div>
				<?php } ;?>
   
<?php endwhile;  endif; wp_reset_postdata(); ?>		
<?php get_footer(); ?>