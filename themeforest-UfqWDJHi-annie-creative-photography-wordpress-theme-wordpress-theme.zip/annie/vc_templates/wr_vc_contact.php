<?php

$args = array(
		'iconclass'=>'',
		'title'=>'',
		'link_type'=>'',
		'url'=>'',
		'url_text'=>'',
		
		
);

extract(shortcode_atts($args, $atts));

$html = '';
$html .= '<p>';
$html .= '<b>'.$title.'</b> ';
if($url != ""){
if($link_type == "st2"){
$html .= '<a href="mailto:'.$url.'">'.$url.'</a>';
} else if($link_type == "st3"){
$html .= '<a href="callto:'.$url.'">'.$url.'</a>';
} else {
$html .= '<a href="'.$url.'">'.$url_text.'</a>';
		  }
}
$html .= '</p>';


 
echo $html;