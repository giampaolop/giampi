<?php $annie_options = get_option('annie'); ?>
<div class="clear light-gap mb-60"></div>
	<!-- Footer -->
    <div id="annie-footer">
        <div class="annie-narrow-content">
            <div class="row">
                <div class="col-md-12 text-center">
				<?php if ($annie_options['footer_sitetitle_opt']!="st2") { ?>
                    <h2 class="footer_tag_line"><?php  bloginfo('name'); ?> <span><?php bloginfo( 'description' ); ?></span></h2>
                <?php } ;?>
                <?php if ($annie_options['footer_copyright_opt']!="st2") { ?>    
					<div class="footer_copyright_info">	<?php echo do_shortcode(($annie_options['copyright']));?></div>
                <?php } ;?>
				</div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Main end -->
<?php wp_footer(); ?>
</body>
</html>