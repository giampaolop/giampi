<?php

class annie_AfterSetupTheme{
		
	static function return_thme_option($string,$str=null){
		global $annie;
		if($str!=null)
		return isset($annie[''.$string.''][''.$str.'']) ? $annie[''.$string.''][''.$str.''] : null;
		else
		return isset($annie[''.$string.'']) ? $annie[''.$string.''] : null;
	}	
	
}
?>