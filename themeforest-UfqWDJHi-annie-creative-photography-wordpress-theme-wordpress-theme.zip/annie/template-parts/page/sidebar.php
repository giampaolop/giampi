<?php $annie_options = get_option('annie'); ?>	
<?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>				
<div class="row">
<div class="col-md-8">
<div class="row">

    <div class="col-md-12 <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
	
												
					<?php the_content();
					wp_link_pages( array(
					'before'      => '<div class="page-links post-details-url">',
					'after'       => '</div>',
					'link_before' => '',
					'link_after'  => '',
					'pagelink'    => '%',
					'separator'   => '',
					) );
					?>
		
       
    </div>

</div>

</div>
<?php if ( is_active_sidebar( 'sidebar-2' ) ) : ?>
<div class="col-md-4">
<?php dynamic_sidebar( 'sidebar-2' ); ?>
</div>
<?php endif;?>
</div>
