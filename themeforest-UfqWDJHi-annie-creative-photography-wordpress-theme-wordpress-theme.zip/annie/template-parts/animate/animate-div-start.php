<?php $annie_options = get_option('annie'); ?>
		
		<?php if($annie_options['index-content-animate'] == 'yes') {?>
		<div class="animate-box" data-animate-effect="fadeInUp">
		<?php } else { ?>
		<?php } ?>	