<?php $annie_options = get_option('annie'); ?>
<?php while ( have_posts() ) : the_post(); ?>
<?php if($annie_options['index-content-animate'] == 'yes') { 
$annie_content_animate ='data-animate-effect="fadeInUp"';
$annie_content_class ="animate-box";
 } else { 
$annie_content_animate ="";
$annie_content_class ="";
 } ;?>
<?php if(get_post_meta($post->ID,'rnr_page_header_block_animate',true)=='yes'){ 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
	<div class="annie-about">
		<div class="container-fluid">
		<?php if(get_post_meta($post->ID,'rnr_page_header_block',true)=='no'){ ?>
		<?php } else { ?>	
            <div class="row">
               <div class="col-md-12 text-center"> 
			   <?php if (( get_post_meta($post->ID,'rnr_page_right_block_header_subtitle',true))):?>
			    <span class="heading-meta"><?php echo esc_html(get_post_meta($post->ID,'rnr_page_right_block_header_subtitle',true)); ?></span>
			   <?php endif; ?>
                <h2 class="<?php echo esc_attr($annie_title_class);?>"  <?php echo esc_attr($annie_title_animate);?>><?php if (( get_post_meta($post->ID,'rnr_page_right_block_header_title',true))):?><?php echo esc_html(get_post_meta($post->ID,'rnr_page_right_block_header_title',true)); ?><?php else: ?><?php the_title();?><?php endif;?></h2> 
				</div>
            </div>
		
			<?php if (has_post_thumbnail( $post->ID ) ):
			$annie_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );?>
            <div class="row">
            <div class="col-md-12 animate-box" data-animate-effect="zoomInDown"> <img src="<?php echo esc_url($annie_image[0]);?>" alt="<?php the_title_attribute();?>" class="img-fluid mb-30"> </div>
            </div>
			<?php endif;?>
		<?php } ;?>
			<div class="row">
            <div class="col-md-12 <?php echo esc_attr($annie_content_class);?>" <?php echo esc_attr($annie_content_animate);?>>
			<div class="page-content">
			<?php the_content();
				 wp_link_pages( array(
				'before'      => '<div class="page-links post-details-url">',
				'after'       => '</div>',
				'link_before' => '',
				'link_after'  => '',
				'pagelink'    => '%',
				'separator'   => '',
				) );													
				?>	
			</div>	
			<?php if ( comments_open() || get_comments_number() ) { ?>
			<div id="comments" class="single-post-comm fl-wrap">
				<?php comments_template();?>
			</div><!-- /.comments-section -->
			<?php }?>										
		</div>
		</div>
		</div>
	</div>
<?php endwhile; // end of the loop. ?>
<?php wp_reset_postdata();?>