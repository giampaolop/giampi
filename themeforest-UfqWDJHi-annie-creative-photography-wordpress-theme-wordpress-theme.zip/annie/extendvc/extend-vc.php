<?php
/*** Removing shortcodes ***/
vc_remove_element("vc_widget_sidebar");
vc_remove_element("vc_gallery");
vc_remove_element("vc_wp_search");
vc_remove_element("vc_wp_meta");
vc_remove_element("vc_wp_recentcomments");
vc_remove_element("vc_wp_calendar");
vc_remove_element("vc_wp_pages");
vc_remove_element("vc_wp_tagcloud");
vc_remove_element("vc_wp_custommenu");
vc_remove_element("vc_wp_text");
vc_remove_element("vc_wp_posts");
vc_remove_element("vc_wp_links");
vc_remove_element("vc_wp_categories");
vc_remove_element("vc_wp_archives");
vc_remove_element("vc_wp_rss");
vc_remove_element("vc_teaser_grid");
vc_remove_element("vc_button");
vc_remove_element("vc_button2");
vc_remove_element("vc_cta_button");
vc_remove_element("vc_cta_button2");
vc_remove_element("vc_message");
vc_remove_element("vc_tour");
vc_remove_element("vc_progress_bar");
vc_remove_element("vc_pie");
vc_remove_element("vc_posts_slider");
vc_remove_element("vc_toggle");
vc_remove_element("vc_images_carousel");
vc_remove_element("vc_posts_grid");
vc_remove_element("vc_carousel");

/*** Remove unused parameters ***/
if (function_exists('vc_remove_param')) {
	vc_remove_param('vc_single_image', 'css_animation');
	vc_remove_param('vc_column_text', 'css_animation');
	vc_remove_param('vc_row', 'video_bg');
	vc_remove_param('vc_row', 'video_bg_url');
	vc_remove_param('vc_row', 'video_bg_parallax');
	vc_remove_param('vc_row', 'full_height');
	vc_remove_param('vc_row', 'content_placement');
	vc_remove_param('vc_row', 'full_width');
	vc_remove_param('vc_row', 'bg_image');
	vc_remove_param('vc_row', 'bg_color');
	vc_remove_param('vc_row', 'font_color');
	vc_remove_param('vc_row', 'margin_bottom');
	vc_remove_param('vc_row', 'bg_image_repeat');
	vc_remove_param('vc_tabs', 'interval');
	vc_remove_param('vc_separator', 'style');
	vc_remove_param('vc_separator', 'color');
	vc_remove_param('vc_separator', 'accent_color');
	vc_remove_param('vc_separator', 'el_width');
	vc_remove_param('vc_text_separator', 'style');
	vc_remove_param('vc_text_separator', 'color');
	vc_remove_param('vc_text_separator', 'accent_color');
	vc_remove_param('vc_text_separator', 'el_width');
	vc_remove_param('vc_row', 'gap');
    vc_remove_param('vc_row', 'columns_placement');
    vc_remove_param('vc_row', 'equal_height');
    vc_remove_param('vc_row_inner', 'gap');
    vc_remove_param('vc_row_inner', 'content_placement');
    vc_remove_param('vc_row_inner', 'equal_height');
    vc_remove_param('vc_hoverbox', 'use_custom_fonts_primary_title');
    vc_remove_param('vc_hoverbox', 'use_custom_fonts_hover_title');
    vc_remove_param('vc_hoverbox', 'hover_add_button');
	vc_remove_param('vc_row', 'parallax');
    vc_remove_param('vc_row', 'parallax_image');
	vc_remove_param('vc_row', 'parallax_speed_bg');
	vc_remove_param('vc_row', 'parallax_speed_video');
	vc_remove_param('vc_row', 'disable_element');
	vc_remove_param('vc_row', 'el_id');
	vc_remove_param('vc_row', 'el_class');
	//vc_remove_param('vc_row', 'css_animation');
}

/*** Remove frontend editor ***/
if(function_exists('vc_disable_frontend')){
	vc_disable_frontend();
}


/*** Row ***/

vc_add_param("vc_row", array(
	"type" => "dropdown",
	"class" => "",
	"show_settings_on_create"=>true,
	"heading" => "Row Type",
	"param_name" => "row_type",
	"value" => array(
		
		"WR Section" => "qubackcolor",
		"Full Width" => "qubackcolorfull",
		
	)
));

//enable title
vc_add_param("vc_row", array(
	"type" => "dropdown",
	"class" => "",
	"heading" => "Title Section",
	"param_name" => "enabletitle",
	"value" => array(
		"Disable" => "st2",	
		"Enable" => "st1",
			
	),
	
));

vc_add_param("vc_row", array(
	"type" => "textfield",
	"class" => "",
	"heading" => "Section Title",
	"value" => "",
	"param_name" => "annie_title",
	"description" => "",
	"dependency" => Array('element' => "enabletitle", 'value' => array('st1'))
));

vc_add_param("vc_row", array(
	"type" => "textfield",
	"class" => "",
	"heading" => "Section Sub Title",
	"value" => "",
	"param_name" => "annie_sub_title",
	"description" => "",
	"dependency" => Array('element' => "enabletitle", 'value' => array('st1'))
));

// title align
vc_add_param("vc_row", array(
	"type" => "dropdown",
	"class" => "",
	"heading" => "Text Align",
	"param_name" => "title_text_align",
	"value" => array(
		"Center" => "st1",	
		"Left" => "st2",
		"Right" => "st3",
			
	),
	"dependency" => Array('element' => "enabletitle", 'value' => array('st1'))
	
));

vc_add_param("vc_row", array(
	"type" => "textfield",
	"class" => "",
	"heading" => "Padding Top",
	"value" => "",
	"param_name" => "padding_top",
	"description" => "e.x:100",
	"dependency" => Array('element' => "row_type", 'value' => array('row','qubackcolor'))
));
vc_add_param("vc_row", array(
	"type" => "textfield",
	"class" => "",
	"heading" => "Padding Bottom",
	"value" => "",
	"param_name" => "padding_bottom",
	"description" => "e.x:80",
	"dependency" => Array('element' => "row_type", 'value' => array('row','qubackcolor'))
));



/***************** Annie Shortcodes *********************/
// Slider Block
class WPBakeryShortCode_WR_VC_Sliders  extends WPBakeryShortCodesContainer {}
//Register "container" content element. It will hold all your inner (child) content elements
vc_map( array(
        "name" => "Annie Slider", "annie",
        "base" => "wr_vc_sliders",
        "as_parent" => array('only' => 'wr_vc_slider'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "content_element" => true,
		"category" => 'bY Annie',
		"icon" => "icon-annie",
        "show_settings_on_create" => true,
        "params" => array(
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Extra Class",
				"param_name" => "class",
				"value" => ""
			),														
        ),
        "js_view" => 'VcColumnView'
) );
class WPBakeryShortCode_WR_VC_Slider extends WPBakeryShortCode {}
vc_map( array(
        "name" => "Annie Slide Item", "annie",
        "base" => "wr_vc_slider",
        "content_element" => true,
		"icon" => "icon-annie",
        "as_child" => array('only' => 'wr_vc_sliders'), // Use only|except attributes to limit parent (separate multiple values with comma)
        "params" => array(					
			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => "Slider's Image",
				"param_name" => "image",
				"description" => ""
			),			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Title Text",
				"param_name" => "title",
				"value" => "",
				"description" => "",
			),

			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Sub Title Text",
				"param_name" => "sub_title",
				"value" => "",
				"description" => "",
			),	
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => "Text Color",
				"param_name" => "color",
				"value" => ""
			),	
		
        )
) );

// Text Block
vc_map( array(
		"name" => "Annie Text Box",
		"base" => "wr_vc_section_text",
		"category" => 'bY Annie',
		"icon" => "icon-wpb-layer-shape-text",
		"allowed_contaiannie_element" => 'vc_row',
		"params" => array(
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Extra Class",
				"param_name" => "class",
				"value" => ""
			),	

			array(
				"type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => "Text Align",
				"param_name" => "float",
				"value" => array(
					"Default" => "",
					"Left" => "text-left",
					"Right" => "text-right",
					"Center" => "text-center",
					"Justify" => "text-justify",
					
				)
			),
			
			array(
				"type" => "textarea_html",
				"holder" => "div",
				"class" => "",
				"heading" => "Content Text",
				"param_name" => "content",
				"value" => "I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo."
			),	
					
			

			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => "Upload Signature Image",
				"param_name" => "image",
				"value" => "Optional"
			),	
					
			
		)
) );

//Image Slider
vc_map( array(
		"name" => esc_html__('Annie Image Gallery', 'annie'),
		"base" => "annie_image_gallery",
		"category" => 'bY Annie',
		"icon" => "icon-annie",
		"allowed_container_element" => 'vc_row',
		"params" => array(
			
			
			
			array(
				"type" => "attach_images",
				"holder" => "div",
				"class" => "",
				"heading" => "Upload Gallery Images",
				"param_name" => "images",
				"description" => "",
				
			),
		
		)
) );


// Team Block
class WPBakeryShortCode_WR_VC_Teams  extends WPBakeryShortCodesContainer {}
//Register "container" content element. It will hold all your inner (child) content elements
vc_map( array(
        "name" => "Annie Team Member", "annie",
        "base" => "wr_vc_teams",
        "as_parent" => array('only' => 'wr_vc_team'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "content_element" => true,
		"category" => 'bY Annie',
		"icon" => "icon-annie",
        "show_settings_on_create" => true,
        "params" => array(
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Class",
				"param_name" => "class",
				"value" => ""
			),	
			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => "Member's Image",
				"param_name" => "image",
				"description" => ""
			),				
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Title Text",
				"param_name" => "title",
				"value" => "",
				"description" => __("Please insert team member name here in format: Robert Lee", 'annie')
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Subtitle Text",
				"param_name" => "title2",
				"value" => "",
				"description" => __("Please insert team member designation here in format: Founder &amp; CEO", 'annie')
			),				
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Animate Effect",
				"param_name" => "animate",
				"value" => "",
				"description" => __("Please insert <a href='https://daneden.github.io/animate.css/' target='_blank'>animate</a></strong> class here in format: fadeInLeft", 'annie')
			),	
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Link URL",
				"param_name" => "button_url",
				"value" => "",
				"description" => "",
				
			),
			
			array(
				"type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => "Link Target",
				"param_name" => "button_target",
				"value" => array(
					"Self" => "_self",
					"Blank" => "_blank",
					"Parent" => "_parent",	
					"Top" => "_top"	
				),
				"description" => "",
			),			
            
        ),
        "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_WR_VC_Team extends WPBakeryShortCode {}
vc_map( array(
        "name" => "Member Social Icon", "annie",
        "base" => "wr_vc_team",
        "content_element" => true,
		"icon" => "icon-annie",
        "as_child" => array('only' => 'wr_vc_teams'), // Use only|except attributes to limit parent (separate multiple values with comma)
        "params" => array(
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Social Icon Class",
				"param_name" => "button_text",
				"value" => "",
				"description" => __("Please insert <strong><a href='https://themify.me/themify-icons' target='_blank'>Themify</a></strong> icon class name here. Ex: instagram")
				
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Link URL",
				"param_name" => "button_url",
				"value" => "",
				"description" => "",
				
			),
			
			array(
				"type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => "Link Target",
				"param_name" => "button_target",
				"value" => array(
					"Self" => "_self",
					"Blank" => "_blank",
					"Parent" => "_parent",	
					"Top" => "_top"	
				),
				"description" => "",
			),
							
            
        )
) );

//Portfolio
vc_map( array(
		"name" => esc_html__('Annie Portfolio', 'annie'),
		"base" => "annie_portfolio",
		"category" => 'bY Annie',
		"icon" => "icon-annie",
		"allowed_container_element" => 'vc_row',
		"params" => array(
			
			
			array(
				"type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => "Image Resize",
				"param_name" => "image_resize",
				"value" => array(
					"Enable" => "st1",
					"Disable" => "st2",
						
				),
				"description" => "",
			),
			
			array(
				"type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => "Icon",
				"param_name" => "show_icon",
				"value" => array(
					"Enable" => "st1",
					"Disable" => "st2",
						
				),
				"description" => "",
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Icon Class",
				"param_name" => "iconclass",
				"value" => "",
				"description" => "<a href='https://museomix.be/doc/Icons-ET-LineIcons.html' target='_blank'>Icon Class List</a>",
				"dependency" => Array('element' => "show_icon", 'value' => array('st1'))
				
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Category Name",
				"param_name" => "categoryname",
				"value" => "",
				"description" => "Use this field if you need.",
				
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__('Post Count', 'annie'),
				"param_name" => "postcount",
				"value" => "",
				
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__('Post Offset', 'annie'),
				"param_name" => "postoffset",
				"value" => "",
				
			),

		)
) );

// wr contact info
class WPBakeryShortCode_WR_VC_Contacts  extends WPBakeryShortCodesContainer {}
//Register "container" content element. It will hold all your inner (child) content elements
vc_map( array(
        "name" => "Annie Contact Info", "annie",
        "base" => "wr_vc_contacts",
        "as_parent" => array('only' => 'wr_vc_contact'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "content_element" => true,
		"category" => 'bY Annie',
		"icon" => "icon-annie",
        "show_settings_on_create" => true,
        "params" => array(
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Class",
				"param_name" => "data_class",
				"value" => ""
			),

			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Title",
				"param_name" => "data_title",
				"value" => ""
			),	

			array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => "Content",
				"param_name" => "data_content",
				"value" => ""
			),	

			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Animate Effect",
				"param_name" => "animate",
				"value" => "",
				"description" => __("Please insert <a href='https://daneden.github.io/animate.css/' target='_blank'>animate</a></strong> class here in format: fadeInLeft", 'annie')
			),				
			
			
			
            
        ),
        "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_WR_VC_Contact extends WPBakeryShortCode {}
vc_map( array(
        "name" => "Contact Info Item", "annie",
        "base" => "wr_vc_contact",
        "content_element" => true,
		"icon" => "icon-annie",
        "as_child" => array('only' => 'wr_vc_contacts'), // Use only|except attributes to limit parent (separate multiple values with comma)
        "params" => array(
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Title",
				"param_name" => "title",
				"value" => "",
				"description" => "e.x: Date:",
			),
			
			
			
			
			array(
				"type" => "dropdown",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__('URL Type', 'annie'),
				"param_name" => "link_type",
				"value" => array(
					"Custom URL" => "st1",
					"Email Address" => "st2",
					"Phone Number" => "st3",
					
				),
				"description" => "",
				
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "URL",
				"param_name" => "url",
				"value" => "",
				"description" => "",
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "URL Text",
				"param_name" => "url_text",
				"value" => "",
				"description" => "",
				"dependency" => Array('element' => "link_type", 'value' => array('st1'))
			),
			
		
        )
) );

// Contact Form Block
vc_map( array(
		"name" => "Annie Contact Form",
		"base" => "wr_vc_contact_form",
		"category" => 'bY Annie',
		"icon" => "icon-annie",
		"allowed_container_element" => 'vc_row',
		"params" => array(
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Extra Class",
				"param_name" => "class",
				"value" => ""
			),	
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Title",
				"param_name" => "data_title",
				"value" => ""
			),	

			array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => "Content",
				"param_name" => "data_content",
				"value" => ""
			),	
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Contact Form 7 ID",
				"param_name" => "contactfromid",
				"value" => "",
				"description" => __("Please insert contact form id number in format: 27", 'annie')
			),				
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Animate Effect",
				"param_name" => "animate",
				"value" => "",
				"description" => __("Please insert <a href='https://daneden.github.io/animate.css/' target='_blank'>animate</a></strong> class here in format: fadeInLeft", 'annie')
			),	  
		)
) );

// Google Map
vc_map( array(
		"name" => "Annie Google Map",
		"base" => "wr_vc_map",
		"category" => 'bY Annie',
		"icon" => "icon-wpb-map-pin",
		"allowed_container_element" => 'vc_row',
		"params" => array(

			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Latitude, Longitude",
				"param_name" => "latitude",
				"value" => "",
				"description" => "Ex: 48.859003, 2.345275",
				
			),
			
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Address",
				"param_name" => "address",
				"value" => "",
				"description" => "Ex: 27th Brooklyn New York, NY 10065",
				
			),
			
			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => "Upload Location Marker",
				"param_name" => "image",
				"description" => "Required.",
				
				
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => "Animate Effect",
				"param_name" => "animate",
				"value" => "",
				"description" => __("Please insert <a href='https://daneden.github.io/animate.css/' target='_blank'>animate</a></strong> class here in format: fadeInLeft", 'annie')
			),				
			
		)
) );
?>