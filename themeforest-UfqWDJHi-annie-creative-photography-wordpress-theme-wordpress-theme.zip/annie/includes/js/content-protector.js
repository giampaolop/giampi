/* =================================================================
* Content Protector JS
* 
* Template:    Tank - Creative Portfolio Showcase WordPress Theme
* Author:      webRedox
* URL:         https://themeforest.net/user/webredox/portfolio
*
================================================================= */
(function ($) {
	'use strict';

window.addEventListener('contextmenu', function (e) { 
    e.preventDefault(); 
}, false);
// PREVENT CLIPBOARD COPYING
document.addEventListener("copy", function(evt){
  // Change the copied text if you want
  evt.clipboardData.setData("text/plain", "Copying is not allowed on this webpage");
  evt.preventDefault();
}, false);

})(jQuery); 