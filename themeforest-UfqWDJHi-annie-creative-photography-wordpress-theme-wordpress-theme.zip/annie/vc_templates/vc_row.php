<?php
$output = $el_class = '';
extract(shortcode_atts(array(
	'el_class' => '',
	'row_type' => 'row',
	'enabletitle' => 'st2',
	'annie_title' => '',
	'annie_sub_title' => '',
	'padding_top' => '',
	'padding_bottom' => '',
	'title_text_align' => '',
	

), $atts));

wp_enqueue_style( 'js_composer_front' );
wp_enqueue_script( 'wpb_composer_front_js' );
wp_enqueue_style('js_composer_custom_css');
//row condition
$annie_class_row_padding =  "";
if($enabletitle == 'st1'){
$annie_class_row_padding =  "annie_custom-row-no-padding";
}
else {
$annie_class_row_padding =  "annie-custom-row";
}
//padding
$annie_class_row_padding_top =  "";
if($padding_top != ""){
$annie_class_row_padding_top =  'padding-top:'.$padding_top.'px!important;';
}
$annie_class_row_padding_bottom =  "";
if($padding_bottom != ""){
$annie_class_row_padding_bottom =  'margin-bottom:'.$padding_bottom.'px!important;';
}

//text_align
$annie_title_align_opt =  "";
if($title_text_align == 'st2'){
$annie_title_align_opt =  "text-left";
}
else if($title_text_align == 'st3'){
$annie_title_align_opt =  "text-right";
}
else {
$annie_title_align_opt =  "text-center";
}
//main row
if($row_type == 'qubackcolorfull'){
$output .='<div class="clear"></div>';
$output .='<div class="annie_full_width" style="'.$annie_class_row_padding_top.' '.$annie_class_row_padding_bottom.'">';
if($enabletitle == 'st1'){
$output .='<div class="row">';
$output .='<div class="col-md-12 '.$annie_title_align_opt.'">';
if($annie_title != ""){
$output .='<span class="heading-meta">'.$annie_title.'</span>';
}
if($annie_sub_title != ""){
$output .='<h2 class="annie-heading animate-box" data-animate-effect="fadeInUp">'.$annie_sub_title.'</h2>';
}
$output .='</div>';
$output .='</div>';
}
  

}


else {
$output .='<div class="clear"></div>';
$output .='<div class="annie-homepage-about" style="'.$annie_class_row_padding_top.' '.$annie_class_row_padding_bottom.'">';
$output .='<div class="container-fluid">';
if($enabletitle == 'st1'){
$output .='<div class="row">';
$output .='<div class="col-md-12 '.$annie_title_align_opt.'">';
if($annie_title != ""){
$output .='<span class="heading-meta">'.$annie_title.'</span>';
}
if($annie_sub_title != ""){
$output .='<h2 class="annie-heading animate-box" data-animate-effect="fadeInUp">'.$annie_sub_title.'</h2>';
}
$output .='</div>';
$output .='</div>';
}
$output .='<div class="row">';
}

if($row_type != 'content_menu'){
	$output .= wpb_js_remove_wpautop($content);
}
if($row_type == 'qubackcolorfull'){
	$output .= '</div>';
}

else {
$output .= '</div></div></div>';
}
echo $output;