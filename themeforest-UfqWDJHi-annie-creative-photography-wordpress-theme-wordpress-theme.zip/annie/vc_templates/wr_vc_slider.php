<?php

$args = array(
		'title'=>'',	
		'sub_title'=>'',	
		'color'=>'',
		'font_size'=>'',
		'font_weight'=>'',
		'line_height'=>'',
		'text_align'=>'',
		'text_transform'=>'',			
		'image'=>'',		
);

extract(shortcode_atts($args, $atts));
if(is_numeric($image)) {
            $doro_image = wp_get_attachment_url( $image );
        } else {
            $doro_image = $image;
        }
$html = '';

	if(is_numeric($image)) {
	$html .='<li style="background-image: url('.$doro_image.');">';		
		$html .= '<div class="overlay"></div>';
		$html .= '<div class="container-fluid">';
			$html .= '<div class="row">';
				$html .= '<div class="col-md-12 js-fullheight slider-text">';
					$html .= '<div class="slider-text-inner">';
						$html .= '<div class="mx-auto frame-inner">';
						if($title != '') {	
							$html .='<h1 style="';				
							if($color != '') { $html .='color:'.$color.';';}  				
							if($font_size != '') { $html .='font-size:'.$font_size.';';}  				
							if($font_weight != '') { $html .='font-weight:'.$font_weight.';';}  				
							if($line_height != '') { $html .='line-height:'.$line_height.';';}  				
							if($text_align != '') { $html .='text-align:'.$text_align.';';}  				
							if($text_transform != '') { $html .='text-transform:'.$text_transform.';';}
							$html .='">'.$title.'</h1>';													
						}									
						$html .= '<h2 style="';
						if($color != '') { $html .='color:'.$color.';';}  				
							if($font_size != '') { $html .='font-size:'.$font_size.';';}  				
							if($font_weight != '') { $html .='font-weight:'.$font_weight.';';}  				
							if($line_height != '') { $html .='line-height:'.$line_height.';';}  				
							if($text_align != '') { $html .='text-align:'.$text_align.';';}  				
							if($text_transform != '') { $html .='text-transform:'.$text_transform.';';}
						$html .= '">'.$sub_title.'</h2> <span class="frame-1"></span> <span class="frame-2"></span> </div>';
						$html .= '</div>';
					$html .= '</div>';
				$html .= '</div>';
			$html .= '</div>';
		
	$html .= '</li>';
	}
	
echo $html;