<?php $annie_options = get_option('annie'); ?>
<?php while ( have_posts() ) : the_post(); ?>	
<?php if(get_post_meta($post->ID,'rnr_page_header_block_animate',true)=='yes'){ 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
		
<!-- Blog -->
            <div class="annie-blog">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12 text-center"> 
						<?php if (( get_post_meta($post->ID,'rnr_page_right_block_header_subtitle',true))):?>
							<span class="heading-meta"><?php echo esc_html(get_post_meta($post->ID,'rnr_page_right_block_header_subtitle',true)); ?></span>
						<?php endif;?>	
                            <h2 class="<?php echo esc_attr($annie_title_class);?>"  <?php echo esc_attr($annie_title_animate);?>><?php if (( get_post_meta($post->ID,'rnr_page_right_block_header_title',true))):?><?php echo esc_html(get_post_meta($post->ID,'rnr_page_right_block_header_title',true)); ?><?php else: ?><?php the_title();?><?php endif;?></h2>
						</div>
                    </div>
					<?php if ( is_active_sidebar( 'sidebar-2' ) ) : ?>
					<?php get_template_part('template-parts/page/sidebar');?>
					<?php else : ?>
                    <?php get_template_part('template-parts/page/block');?>
                    <?php endif;?>
                </div>
            </div>
<?php endwhile; // end of the loop. ?>
<?php wp_reset_postdata();?>	