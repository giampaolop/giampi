<?php 
require (ANNIE_THEME_PATH . '/includes/core/ac/system-file.php');
add_action('init', 'annie_removeDemoModeLink');
?>