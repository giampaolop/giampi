<?php

$args = array(
    	'data_class'=>'',
    	'data_title'=>'',
    	'data_content'=>'',
    	'animate'=>'fadeInUp',
		
);

$html = "";

extract(shortcode_atts($args, $atts));

		
		
		$html .= '<div class="'.$data_class.' annie-con-class  mb-30 animate-box" data-animate-effect="'.$animate.'">';
		$html .= '<h3 class="annie-contact-heading">'.$data_title.'</h3>';
		$html .= '<p>'.$data_content.'</p>';
		$html .= do_shortcode($content);
		$html .= '</div>';
		
		


echo $html;