<?php $annie_options = get_option('annie'); ?>
<?php get_header();?>
<?php if($annie_options['index-header-animate'] == 'yes') { 
$annie_title_animate ='data-animate-effect="fadeInUp"';
$annie_title_class ="annie-heading animate-box";
 } else { 
$annie_title_animate ="";
$annie_title_class ="annie-heading";
 } ;?>
<!-- Blog -->
<div class="annie-blog">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-center"> 
			<?php if(!empty($annie_options['blog-page-subtitle'])): ?>
				<span class="heading-meta"><?php echo esc_html(($annie_options['blog-page-subtitle']));?></span>
			<?php endif;?>	
                <h2 class="<?php echo esc_attr($annie_title_class);?>" <?php echo esc_attr($annie_title_animate);?>>
			<?php if(!empty($annie_options['blog-page-title'])) { ?>
				<?php echo esc_html(($annie_options['blog-page-title']));?>
			<?php } else { ?>
				<?php esc_html_e('News &amp; Blog','annie');?>
			<?php } ;?>	
				</h2> 
			</div>
        </div>
		<?php if ( is_active_sidebar( 'sidebar-1' ) ) { ?>
			<?php get_template_part('template-parts/index/sidebar');?>
		<?php } else { ?>
            <?php get_template_part('template-parts/index/block');?>
        <?php } ;?>
    </div>
</div>
<?php get_footer(); ?>		