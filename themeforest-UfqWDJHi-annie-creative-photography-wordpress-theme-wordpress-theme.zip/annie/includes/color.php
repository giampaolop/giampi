<?php
add_action('wp_head', 'anniee_custom_colors', 160);
function anniee_custom_colors() { 
$anniee_options = get_option('anniee');
?>
 
<style type="text/css" class="anniee-custom-dynamic-css">
<?php if(!empty(annie_AfterSetupTheme::return_thme_option('sidebar_back_img','url'))) { ?>
.annie-aside {
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
    transition: 0.5s;
    -webkit-box-shadow: 0 0 30px rgba(0, 0, 0, 0.02);
    box-shadow: 0 0 30px rgba(0, 0, 0, 0.02);
    background-position: center;
	background-image: linear-gradient(to bottom, <?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('sidebar_back_img_overlay','rgba'));?>, <?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('sidebar_back_img_overlay','rgba'));?>), url(<?php echo esc_url(annie_AfterSetupTheme::return_thme_option('sidebar_back_img','url'));?>);
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: scroll;
}
<?php } ;?>
<?php if(!empty(annie_AfterSetupTheme::return_thme_option('sidebar_back_menu_border_color','rgba'))) { ?>
.annie-aside .annie-main-menu > ul > li > a, .annie-aside .annie-main-menu > ul > li:last-child > a, .annie-aside .annie-main-menu > ul > li.last > a, .annie-aside .annie-main-menu ul ul li a, .annie-aside .annie-main-menu > ul > li.open > a, .annie-aside .annie-main-menu > ul > li > ul > li:last-child > a, .annie-aside .annie-main-menu > ul > li > ul > li.last > a{
	border-color: <?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('sidebar_back_menu_border_color','rgba'));?>;
	}
<?php } ;?>
<?php if(!empty(annie_AfterSetupTheme::return_thme_option('opt_theme_site_to_top_progress_bar','rgba'))) { ?>
body .progress-wrap {
    -webkit-box-shadow: inset 0 0 0 2px <?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('opt_theme_site_to_top_progress_bar','rgba'));?>;
    box-shadow: inset 0 0 0 2px <?php echo esc_attr(annie_AfterSetupTheme::return_thme_option('opt_theme_site_to_top_progress_bar','rgba'));?>;
}
<?php } ;?>
<?php if (annie_AfterSetupTheme::return_thme_option('scrollbar_opt')!='st2'){ ?>
::-webkit-scrollbar {
    width: 0px;
}

::-webkit-scrollbar-track {
    background: #fff;
}

::-webkit-scrollbar-thumb {
    background: #101010;
}

::-webkit-scrollbar-thumb:hover {
    background: #101010;
}
html{
scrollbar-width: none; /* Firefox */
-ms-overflow-style: none;  /* IE 10+ */
}
<?php } ;?>
</style>
 
 <?php 
	}
?>
